// content.js

// Fungsi untuk mengambil csrfToken
function getCsrfToken() {
  const csrfToken = document.querySelector('meta[name="csrf-token"]'); // Sesuaikan selector jika diperlukan
  return csrfToken ? csrfToken.getAttribute("content") : null;
}

// Fungsi untuk mengambil teks dari elemen tertentu di halaman PISN
function getPisnHtml() {
  const targetElement = document.querySelector('.bg-white.text-center.w-100.mb-4 p');
  if (targetElement) {
    const textContent = targetElement.textContent.trim();
    // Cek apakah teks mengandung kata-kata seperti "Data yang diberikan PDDikti"
    if (textContent.includes("Data yang diberikan PDDikti")) {
      // Simpan teks ke chrome.storage.local
      chrome.storage.local.set({ datePddikti: textContent }, () => {
        console.log("Teks PDDikti berhasil disimpan:", textContent);
      });
    }
    return textContent;
  }
  return "Cek Eligible PISN"; // Fallback jika elemen tidak ditemukan
}

// Ambil CSRF Token dan kirim ke background.js
const token = getCsrfToken();
if (token) {
  chrome.storage.local.set({ csrfToken: token }, () => {
    console.log("CSRF Token stored:", token);
  });
  chrome.runtime.sendMessage({ action: "setCsrfToken", csrfToken: token });
}

// Ambil teks PISN dan kirimkan ke background.js
const pisnData = getPisnHtml();
chrome.runtime.sendMessage({ action: "receivePisnHtml", data: pisnData });
