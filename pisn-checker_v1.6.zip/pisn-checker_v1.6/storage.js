document.addEventListener("DOMContentLoaded", function () {
    
    // Initially hide the storage items
    const storageList = document.getElementById('storageList');
    storageList.style.display = 'none'; // Hide storage list by default
    
    // Listen for "Alt + I" key press to toggle visibility of storage items
    document.addEventListener('keydown', function(event) {
        if (event.altKey && event.key === 'i') { // Check if Alt + I is pressed
            toggleStorageVisibility(); // Toggle visibility
        }
    });

    // Function to toggle visibility of the storage list
    function toggleStorageVisibility() {
        if (storageList.style.display === 'none') {
            storageList.style.display = 'block'; // Show items
        } else {
            storageList.style.display = 'none'; // Hide items
        }
    }

    // Load items from chrome.storage.local and display them
    loadLocalStorage();

    // Handle "Add Item" button click
    document.getElementById('saveItemBtn').addEventListener('click', function() {
        let key = document.getElementById('addKey').value;
        let value = document.getElementById('addValue').value;

        if (key && value) {
            // Set the item in chrome.local storage
            chrome.storage.local.set({ [key]: value }, function() {
                loadLocalStorage(); // Reload localStorage data
                $('#addModal').modal('hide'); // Close modal
                // Clear inputs
                document.getElementById('addKey').value = '';
                document.getElementById('addValue').value = '';
            });
        } else {
            alert("Key and Value are required!");
        }
    });

    // Function to load and display chrome.storage.local items
    function loadLocalStorage() {
        storageList.innerHTML = ''; // Clear existing list

        // Get all items from chrome.storage.local
        chrome.storage.local.get(null, function(items) {
            for (let key in items) {
                if (items.hasOwnProperty(key)) {
                    let value = items[key];

                    // Create list item
                    let itemDiv = document.createElement('div');
                    itemDiv.classList.add('list-group-item', 'd-flex', 'justify-content-between', 'align-items-center');
                    itemDiv.classList.add('key-value');
                    itemDiv.innerHTML = `
                        <span>${key}: ${value}</span>
                        <div>
                            <button class="btn btn-warning btn-sm me-2" id="editBtn-${key}">Edit</button>
                            <button class="btn btn-danger btn-sm" id="deleteBtn-${key}">Hapus</button>
                        </div>
                    `;
                    storageList.appendChild(itemDiv);

                    // Add event listeners for Edit and Delete buttons
                    document.getElementById(`editBtn-${key}`).addEventListener('click', function () {
                        editItem(key);
                    });
                    document.getElementById(`deleteBtn-${key}`).addEventListener('click', function () {
                        deleteItem(key);
                    });
                }
            }
        });
    }

    // Edit Item function
    function editItem(key) {
        // Get the current value
        chrome.storage.local.get([key], function(result) {
            let currentValue = result[key];

            // Prompt user for new value
            let newValue = prompt("Edit value for " + key, currentValue);
            if (newValue !== null) {
                chrome.storage.local.set({ [key]: newValue }, function() {
                    loadLocalStorage(); // Reload items after edit
                });
            }
        });
    }

    // Delete Item function
    function deleteItem(key) {
        console.log("Attempting to delete item with key:", key);  // Debugging log
        if (confirm(`Are you sure you want to delete the item with key: "${key}"?`)) {
            chrome.storage.local.remove([key], function() {
                console.log("Item removed from storage:", key);  // Debugging log
                loadLocalStorage(); // Reload items after delete
            });
        }
    }
});
    