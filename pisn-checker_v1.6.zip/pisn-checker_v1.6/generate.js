/* generate.js (recreated)
   - Menyimpan kembali fungsi lama
   - Menambahkan: getNeofeederToken, getMahasiswa, proses NIM multi-baris
   - Event handler untuk tombol #btnGenerateIdRegPd (harapkan ada di HTML)
*/

let csrfToken;
let idPddikti;
let neofeederUrl = null;
let neofeederToken = null;

/* Ambil CSRF token dari storage extension (dipakai untuk request ke PISN) */
function getCsrfToken() {
    chrome.storage.local.get(['csrfToken'], function (result) {
        csrfToken = result.csrfToken || '';
        $('#_token').val(csrfToken);
        getIdPddikti();
    });
}

/* Ambil institution code dari storage */
function getInstitutionCode() {
    chrome.storage.local.get(['kodept'], function (result) {
        const institutionCode = result.kodept || '';
        $('#institution_code').val(institutionCode);
    });
}

/* Ambil ID PDDIKTI dari storage dan panggil fetchStudyPrograms */
function getIdPddikti() {
    chrome.storage.local.get(['idpt'], function (result) {
        idPddikti = result.idpt ? result.idpt.toUpperCase() : '';
        if (idPddikti) {
            fetchStudyPrograms(idPddikti);
        } else {
            console.error("ID PDDIKTI tidak ditemukan");
        }
    });
}

/* Ambil daftar program studi dari Neofeeder (simpan neofeederUrl & token untuk dipakai lagi) */
function fetchStudyPrograms(idPddiktiParam) {
    $('#loading').show();

    chrome.storage.local.get(['url', 'username', 'password'], (config) => {
        const { url, username, password } = config;

        if (!url || !username || !password) {
            console.error('Konfigurasi Neofeeder belum lengkap.');
            alert('Silakan atur koneksi Neofeeder terlebih dahulu.');
            $('#loading').hide();
            return;
        }

        // simpan URL global agar bisa dipakai fungsi lain (mis. getMahasiswa)
        neofeederUrl = url;

        // Step 1: Ambil token Neofeeder
        $.ajax({
            url,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ act: 'GetToken', username, password }),
            success: function (response) {
                try {
                    const token = response.data?.token;
                    if (!token) throw new Error('Token Neofeeder tidak ditemukan pada response.');
                    neofeederToken = token;

                    // Step 2: Ambil Prodi
                    $.ajax({
                        url,
                        method: 'POST',
                        contentType: 'application/json',
                        data: JSON.stringify({ act: 'GetProdi', token }),
                        success: function (res) {
                            if (res.error_code === 0 && Array.isArray(res.data)) {
                                const formatted = res.data.map(prodi => ({
                                    id: prodi.id_prodi,
                                    nama: prodi.nama_program_studi,
                                    kode: prodi.kode_program_studi,
                                    jenjang: mapJenjang(prodi.id_jenjang_pendidikan)
                                }));
                                populateDropdown(formatted);
                            } else {
                                console.error(res.error_desc || res);
                                alert('Gagal mengambil data prodi dari Neofeeder.');
                            }
                        },
                        error: () => alert('Terjadi kesalahan saat mengambil program studi.'),
                        complete: () => $('#loading').hide()
                    });
                } catch (err) {
                    console.error(err);
                    alert('Respons token Neofeeder tidak valid.');
                    $('#loading').hide();
                }
            },
            error: () => {
                alert('Gagal mendapatkan token dari Neofeeder.');
                $('#loading').hide();
            }
        });
    });
}

function mapJenjang(idJenjang) {
    const map = {
        "20": "D1", "21": "D2", "22": "D3", "23": "D4",
        "30": "S1", "31": "Profesi", "32": "Spesialis 1",
        "33": "Spesialis 2", "34": "Subspesialis",
        "35": "S2", "36": "S2 Terapan", "40": "S3", "41": "S3 Terapan"
    };
    return map[idJenjang] || "Unknown";
}

function populateDropdown(programs) {
    const dropdown = $('#institution_study_program_id');
    dropdown.empty();
    dropdown.append('<option value="">Pilih Program Studi</option>');

    programs.forEach(program => {
        dropdown.append(
            `<option value="${program.id}" data-kode="${program.kode}">${program.jenjang} - ${program.nama.toUpperCase()}</option>`
        );
    });
}

/* Handling error response dari server PISN */
function handleError(jqXHR) {
    if (jqXHR.responseJSON?.message === "Unauthenticated.") {
        Swal.fire({
            icon: 'warning',
            title: 'Session Login PISN Tidak Ditemukan',
            html: 'Silakan login terlebih dahulu di <a href="https://pisn.kemdikbud.go.id/login" target="_blank">pisn.kemdikbud.go.id/login</a>',
            confirmButtonText: 'OK'
        });
    } else {
        Swal.fire({
            icon: 'error',
            title: 'Kesalahan',
            text: 'Terjadi kesalahan saat menghasilkan sertifikat.',
            confirmButtonText: 'OK'
        });
    }
}

/* Wrapper generic untuk request ke PISN (menggunakan csrfToken) */
function makeRequest(url, data, contentType, processData, onSuccess, onError) {
    $.ajax({
        url,
        method: 'POST',
        data,
        contentType,
        processData,
        beforeSend: xhr => {
            xhr.setRequestHeader("X-Csrf-Token", csrfToken);
            xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
        },
        success: onSuccess,
        error: onError
    });
}

/* ==========================
   NEOTEFEEDER HELPERS
   ========================== */

/* Ambil token Neofeeder (cached). Kembalikan promise yang resolve ke token. */
function getNeofeederToken() {
    return new Promise((resolve, reject) => {
        if (neofeederToken && neofeederUrl) {
            return resolve(neofeederToken);
        }

        // Ambil konfigurasi dari storage
        chrome.storage.local.get(['url', 'username', 'password'], (config) => {
            const { url, username, password } = config;
            if (!url || !username || !password) {
                return reject(new Error('Konfigurasi Neofeeder belum lengkap.'));
            }
            neofeederUrl = url;

            $.ajax({
                url,
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ act: 'GetToken', username, password }),
                success: function (response) {
                    try {
                        const token = response.data?.token;
                        if (!token) throw new Error('Token Neofeeder tidak ditemukan.');
                        neofeederToken = token;
                        resolve(token);
                    } catch (err) {
                        reject(err);
                    }
                },
                error: (xhr, status, err) => {
                    reject(err || new Error('Gagal mendapatkan token Neofeeder'));
                }
            });
        });
    });
}

/* Ambil data mahasiswa lengkap berdasarkan NIM.
   - Mengembalikan Promise yang resolve ke object: { nim, id_reg, id_prodi, id_periode_masuk, nik }.
   - Jika tidak ditemukan, id_reg = null.
*/
function getMahasiswa(token, nim) {
    return new Promise((resolve, reject) => {
        // pastikan neofeederUrl ada
        if (!neofeederUrl) {
            // coba ambil dari storage
            chrome.storage.local.get(['url'], (cfg) => {
                if (!cfg.url) {
                    return reject(new Error('URL Neofeeder tidak tersedia.'));
                }
                neofeederUrl = cfg.url;
                // lanjutkan request
                _callGetMahasiswa();
            });
        } else {
            _callGetMahasiswa();
        }

        function _callGetMahasiswa() {
            $.ajax({
                url: neofeederUrl,
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({
                    act: 'GetDataLengkapMahasiswaProdi',
                    token: token,
                    filter: `nim='${nim}'`
                }),
                success: (response) => {
                    try {
                        const data = Array.isArray(response.data) ? response.data[0] : null;
                        if (data) {
                            resolve({
                                nim: nim,
                                id_reg: data.id_registrasi_mahasiswa || null,
                                id_prodi: data.id_prodi || null,
                                id_periode_masuk: data.id_periode_masuk || null,
                                nik: data.nik || null
                            });
                        } else {
                            // tidak ditemukan
                            resolve({
                                nim: nim,
                                id_reg: null,
                                id_prodi: null,
                                id_periode_masuk: null,
                                nik: null
                            });
                        }
                    } catch (err) {
                        console.error('Error parsing mahasiswa response', err);
                        reject(err);
                    }
                },
                error: (xhr, status, error) => {
                    console.error('Error fetching mahasiswa data:', error);
                    reject(error || new Error('HTTP error saat GetDataLengkapMahasiswaProdi'));
                }
            });
        }
    });
}

/* Proses list NIM (textarea per baris atau input single) -> keluaran:
   - #resultList (textarea) berisi "nim,id_reg" tiap baris
   - #id_reg_pd diisi dengan id_reg yang valid, dipisah koma (digunakan untuk generate certificate)
*/
async function processNimListAndFillIdRegs() {
    // ambil nilai NIM dari textarea (preferensi #nimList). fallback ke #nim single-line
    let raw = '';
    if ($('#nimList').length) {
        raw = $('#nimList').val() || '';
    } else if ($('#nim').length) {
        raw = $('#nim').val() || '';
    } else {
        Swal.fire('Error', 'Element input NIM (#nimList atau #nim) tidak ditemukan di halaman.', 'error');
        return;
    }

    // normalisasi: split per baris atau koma
    let nimCandidates = raw.split(/\r?\n|,/).map(s => s.trim()).filter(s => s !== '');
    if (nimCandidates.length === 0) {
        Swal.fire('Error', 'Tidak ada NIM yang dimasukkan.', 'error');
        return;
    }

    $('#loading').show();
    $('#result').empty && $('#result').empty();
    $('#resultContainer').show && $('#resultContainer').show();

    try {
        const token = await getNeofeederToken();
        const results = [];
        const idRegsFound = [];

        // serial loop (lebih aman terhadap limit)
        for (const nim of nimCandidates) {
            try {
                const data = await getMahasiswa(token, nim);
                if (data && data.id_reg) {
                    results.push(`${data.nim},${data.id_reg}`);
                    idRegsFound.push(data.id_reg);
                    // optional detail render (jika ada #result div)
                    $('#result').append
                        ? $('#result').append(`<div><strong>${data.nim}</strong> → <span style="color:green">${data.id_reg}</span> (Prodi: ${data.id_prodi || '-'}, Periode: ${data.id_periode_masuk || '-'})</div>`)
                        : null;
                } else {
                    results.push(`${nim},(ID_REG_NOT_FOUND)`);
                    $('#result').append
                        ? $('#result').append(`<div><strong>${nim}</strong> → <span style="color:red">(ID REG NOT FOUND)</span></div>`)
                        : null;
                }
            } catch (err) {
                console.error('Error for NIM', nim, err);
                results.push(`${nim},(ERROR)`);
                $('#result').append
                    ? $('#result').append(`<div><strong>${nim}</strong> → <span style="color:orange">(ERROR)</span></div>`)
                    : null;
            }
        }
            // tampilkan hasil (textarea)
            if ($('#resultList').length) {
                $('#resultList').val(results.join('\n').toUpperCase());
            } else {
                // jika tidak ada textarea hasil, tambahkan ke #resultContainer
                $('#resultContainer').show && $('#resultContainer').show();
            }


        // isi #id_reg_pd hanya dengan id_reg yang valid (dipakai untuk generate)
        const idRegValue = idRegsFound.join(',');
        $('#id_reg_pd').val(idRegValue);

        Swal.fire('Selesai', `Proses pencarian NIM selesai. Ditemukan ${idRegsFound.length} id_reg dari ${nimCandidates.length} NIM.`, 'success');
    } catch (err) {
        console.error('Gagal memproses NIM list:', err);
        Swal.fire('Error', 'Gagal memproses NIM. Periksa konfigurasi Neofeeder.', 'error');
    } finally {
        $('#loading').hide();
    }
}

/* ==========================
   EVENT HANDLERS & FORM SUBMIT
   ========================== */

$(document).ready(function () {
    // ambil token csrf dan kode instansi
    getCsrfToken();
    getInstitutionCode();


    // search prodi input (filter dropdown)
    $('#search_institution_study_program').on('input', function () {
        const search = $(this).val().toLowerCase();
        let matched = [];

        $('#institution_study_program_id option').each(function () {
            const text = $(this).text().toLowerCase();
            if (text.includes(search) || search === '') {
                $(this).show();
                matched.push(this);
            } else {
                $(this).hide();
            }
        });

        if (matched.length === 1) {
            $(matched[0]).prop('selected', true);
            $('#institution_study_program_id').trigger('change');
        } else {
            $('#institution_study_program_id').val('');
            $('#study_program_code').val('');
            $('#institution_study_program_id_input').val('');
        }
    });

    // saat pilih prodi -> isi kode dan id prodi input
    $('#institution_study_program_id').on('change', function () {
        const selected = $(this).find('option:selected');
        const id = selected.val();
        const kode = selected.data('kode');
        $('#study_program_code').val(id ? kode : '');
        $('#institution_study_program_id_input').val(id ? id.toUpperCase() : '');
    });

    // pastikan id_reg_pd uppercase
    $('#id_reg_pd').on('input', function () {
        this.value = this.value.toUpperCase();
    });

    // Tombol: Generate ID Reg PD dari NIM (harapkan ada tombol dengan id ini di HTML)
    $(document).on('click', '#btnGenerateIdRegPd', function () {
        processNimListAndFillIdRegs();
    });

    // Jika ingin tombol lain (mis. #btnFetchIdReg) juga bekerja, tambahkan listener:
    $(document).on('click', '#btnFetchIdReg', function () {
        processNimListAndFillIdRegs();
    });


$("#loadingOverlay").hide();
    // Submit form -> tetap gunakan alur lama, namun sanitasi id_reg_pd sebelum submit
// ---------- Replace form submit handler with this ----------
$('#generateForm').on('submit', function (e) {
    e.preventDefault();

    // Tampilkan overlay loading saat proses dimulai
    $("#loadingOverlay").show();

    const formEl = this;
    const formData = new FormData(formEl);
    const _token = $('#_token').val();
    const institution_code = $('#institution_code').val();
    const study_program_code = $('#study_program_code').val();
    const institution_study_program_id = $('#institution_study_program_id_input').val();
    const proengsoft_jsvalidation = $('#proengsoft_jsvalidation').val();

    // 1) Ambil id_reg dari #id_reg_pd (jika ada)
    let id_reg_pd_array = [];
    const idRegFromInput = ($('#id_reg_pd').length ? $('#id_reg_pd').val().trim() : '');

    if (idRegFromInput) {
        // support "id1,id2,..." and also "id1 id2"
        id_reg_pd_array = idRegFromInput.split(/[\s,]+/).map(x => x.trim()).filter(Boolean);
    } else if ($('#resultList').length) {
        // 2) Jika tidak ada #id_reg_pd, parse #resultList (format: nim,id_reg per baris)
        const raw = $('#resultList').val() || '';
        const lines = raw.split(/\r?\n/).map(l => l.trim()).filter(Boolean);

        lines.forEach(line => {
            // line bisa "nim,idreg" atau hanya "idreg"
            const parts = line.split(',').map(p => p.trim()).filter(Boolean);
            if (parts.length >= 2) {
                const maybeId = parts[1];
                if (maybeId && !/^\(|^\s*ERROR|^\s*ID_REG_NOT_FOUND/i.test(maybeId)) {
                    id_reg_pd_array.push(maybeId);
                }
            } else if (parts.length === 1) {
                const single = parts[0];
                if (/^[0-9a-fA-F\-]{20,}$/.test(single) && !/^\(|^\s*ERROR|^\s*ID_REG_NOT_FOUND/i.test(single)) {
                    id_reg_pd_array.push(single);
                }
            }
        });
    }

    // Sanitasi akhir: trim, hapus placeholder, dan dedup
    id_reg_pd_array = id_reg_pd_array
        .map(x => x.trim())
        .filter(x => x !== '' && !/^\(|^\s*ERROR|^\s*ID_REG_NOT_FOUND/i.test(x));
    id_reg_pd_array = [...new Set(id_reg_pd_array)]; // unique

    if (id_reg_pd_array.length === 0) {
        $("#loadingOverlay").hide(); // sembunyikan loading
        Swal.fire('Error', 'Tidak ada ID Reg PD valid untuk diproses. Silakan generate ID Reg PD terlebih dahulu.', 'error');
        return;
    }

    // Pastikan compatibility: simpan juga ke #id_reg_pd (buat hidden jika belum ada)
    if ($('#id_reg_pd').length) {
        $('#id_reg_pd').val(id_reg_pd_array.join(','));
    } else {
        $(formEl).append($('<input>', {
            type: 'hidden',
            id: 'id_reg_pd',
            name: 'id_reg_pd',
            value: id_reg_pd_array.join(',')
        }));
    }

    const yudisium_letter = $('#yudisium_letter')[0]?.files?.[0];
    const statement_letter = $('#statement_letter')[0]?.files?.[0];
    const baseUrl = "https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/generate";
    const baseUrldirect = "https://pisn.kemdiktisaintek.go.id/operator/generated-certificate";

    const firstData = {
        _token,
        institution_code,
        study_program_code,
        institution_study_program_id,
        proengsoft_jsvalidation,
        id_reg_pd: id_reg_pd_array,
        _jsvalidation: 'yudisium_letter',
        _jsvalidation_validate_all: false
    };

    const secondData = {
        _token,
        institution_code,
        study_program_code,
        institution_study_program_id,
        proengsoft_jsvalidation,
        id_reg_pd: id_reg_pd_array,
        _jsvalidation: 'statement_letter',
        _jsvalidation_validate_all: false
    };

    const thirdData = new FormData();
    thirdData.append('_token', _token);
    thirdData.append('institution_code', institution_code);
    thirdData.append('study_program_code', study_program_code);
    thirdData.append('institution_study_program_id', institution_study_program_id);
    thirdData.append('proengsoft_jsvalidation', proengsoft_jsvalidation);
    id_reg_pd_array.forEach(id => thirdData.append('id_reg_pd[]', id));
    if (yudisium_letter) thirdData.append('yudisium_letter', yudisium_letter);
    if (statement_letter) thirdData.append('statement_letter', statement_letter);

    // Jalankan 3 langkah request seperti alur lama
    makeRequest(
        baseUrl,
        $.param(firstData),
        "application/x-www-form-urlencoded; charset=UTF-8",
        true,
        () => {
            makeRequest(
                baseUrl,
                $.param(secondData),
                "application/x-www-form-urlencoded; charset=UTF-8",
                true,
                () => {
                    makeRequest(
                        baseUrl,
                        thirdData,
                        false,
                        false,
                        () => {
                            $("#loadingOverlay").hide(); // proses selesai
                            console.log("Sertifikat berhasil di-generate.");
                            window.open(baseUrldirect, "_blank");
                        },
                        (xhr, status, error) => {
                            $("#loadingOverlay").hide();
                            handleError(xhr, status, error);
                        }
                    );
                },
                (xhr, status, error) => {
                    $("#loadingOverlay").hide();
                    handleError(xhr, status, error);
                }
            );
        },
        (xhr, status, error) => {
            $("#loadingOverlay").hide();
            handleError(xhr, status, error);
        }
    );
});
// ---------- end replacement ----------


});
