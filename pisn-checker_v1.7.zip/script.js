document.addEventListener("DOMContentLoaded", function () {
    console.log("DOM content fully loaded and parsed.");

    // Ambil elemen-elemen yang diperlukan
    const apiForm = document.getElementById('apiForm');
    const downloadButton = document.getElementById('downloadButton');
    const progress = document.getElementById('progress');
    const responseError = document.getElementById('responseError');
    const responseBody = document.getElementById('responseBody');
    const progressContainer = document.getElementById('progressContainer');

    // Sembunyikan tombol download saat halaman pertama kali dimuat
    downloadButton.style.display = 'none';
    progressContainer.style.display = 'none';

    // Fungsi untuk menambahkan data mahasiswa ke tabel
    function addStudentDataToTable(studentId, data, errorMessage) {
        const message = errorMessage || (data.message || 'N/A');
        const student = data.students_data || {};  // Pastikan students_data ada, meskipun kosong

        const row = document.createElement('tr');
    
        // Mengambil NIK dan mengecek kondisi eligibility
        let nikValue = student.nik?.value || 'N/A';
        let nikColor = 'red';  // Default warna merah jika tidak eligible
        let nikTitle = student.nik?.hint || '';  // Ambil hint jika ada
        if (student.nik?.eligible === "1") {
            nikColor = 'green';
        }

        // Menangani masa_belajar
        let masaBelajarValue = student.masa_belajar?.value || 'N/A';
        let masaBelajarUnit = student.masa_belajar?.unit || '';
        let masaBelajarColor = 'red';  // Default warna merah jika tidak eligible
        let masaBelajarHint = student.masa_belajar?.hint || '';  // Ambil hint jika ada
        if (student.masa_belajar?.eligible === "1") {
            masaBelajarColor = 'green';
        }

        // Menangani jumlah_sks
        let jumlahSksValue = student.jumlah_sks?.value || 'N/A';
        let jumlahSksUnit = student.jumlah_sks?.unit || '';
        let jumlahSksColor = 'red';  // Default warna merah jika tidak eligible
        let jumlahSksHint = student.jumlah_sks?.hint || '';  // Ambil hint jika ada
        if (student.jumlah_sks?.eligible === "1") {
            jumlahSksColor = 'green';
        }

        // Menangani IPK
        let ipkValue = student.ipk?.value || 'N/A';
        let ipkUnit = student.ipk?.unit || '';
        let ipkColor = 'red';  // Default warna merah jika tidak eligible
        let ipkHint = student.ipk?.hint || '';  // Ambil hint jika ada
        if (student.ipk?.eligible === "1") {
            ipkColor = 'green';
        }

        // Menangani Pencatatan PDDIKTI
        let pencatatanValue = student.pencatatan_pddikti?.value || 'N/A';
        let pencatatanUnit = student.pencatatan_pddikti?.unit || '';
        let pencatatanColor = 'red';  // Default warna merah jika tidak eligible
        let pencatatanHint = student.pencatatan_pddikti?.hint || '';  // Ambil hint jika ada
        if (student.pencatatan_pddikti?.eligible === "1") {
            pencatatanColor = 'green';
        }

        // Menangani Akreditasi Program Studi
        let akreditasiValue = student.akreditasi_program_studi?.value || null;
        let akreditasiHint = student.akreditasi_program_studi?.hint || '';
        let akreditasiColor = 'red';  // Default warna merah jika null
        if (akreditasiValue !== null) {
            akreditasiColor = 'green';
        }

        row.innerHTML = `
            <td><a href="mahasiswa_neofeeder.html?nim=${studentId}" target="a_blank">${studentId}</a></td>
            <td>${message}</td>
            <td>${student.eligible ? 'Yes' : 'No'}</td>
            <td>${student.eligible_status || 'N/A'}</td>
            <td>${student.nama_mahasiswa?.value || 'N/A'}</td>
            <td>${student.certificate_number || 'N/A'}</td>
            <td>${student.batch_number || 'N/A'}</td>
            <td>${student.eligible_status_description || 'N/A'}</td>
            <td style="color: ${nikColor};" title="${nikTitle}">${nikValue}</td>
            <td>${student.tgl_keluar || 'N/A'}</td>
            <td>${student.tgl_sk_yudisium || 'N/A'}</td>
            <td>${student.no_seri_ijazah || 'N/A'}</td>
            <td>${student.id_jns_keluar || 'N/A'}</td>
            <td style="color: ${akreditasiColor};" title="${akreditasiHint}">${student.akreditasi_program_studi?.value || 'N/A'}</td>
            <td style="color: ${masaBelajarColor};" title="${masaBelajarHint}">${student.masa_belajar?.value || 'N/A'} ${student.masa_belajar?.unit || ''}</td>
            <td style="color: ${jumlahSksColor};" title="${jumlahSksHint}">${student.jumlah_sks?.value || 'N/A'} ${student.jumlah_sks?.unit || ''}</td>
            <td style="color: ${ipkColor};" title="${ipkHint}">${student.ipk?.value || 'N/A'}</td>
            <td>${student.sks_semester_antara?.value || 'N/A'} ${student.sks_semester_antara?.unit || ''}</td>
            <td style="color: ${pencatatanColor};" title="${pencatatanHint}">${student.pencatatan_pddikti?.value || 'N/A'} ${student.pencatatan_pddikti?.unit || ''}</td>
            <td>${student.is_accredited ? 'Yes' : 'No'}</td>
        `;
        responseBody.appendChild(row);
    }

    // Event listener untuk form submit
    apiForm.addEventListener('submit', function (event) {
    event.preventDefault();
    responseBody.innerHTML = ''; // Hapus data tabel sebelumnya
    responseError.textContent = ''; // Bersihkan error sebelumnya

    // Ambil institutionCode dari chrome.storage.local jika ada, atau dari elemen jika tidak
    chrome.storage.local.get('kodept', (result) => {
        let institutionCode = result.kodept ? result.kodept : document.getElementById('institutionCode').value.trim();

        const nimProdiInput = document.getElementById('nimInput').value.trim();
        const records = nimProdiInput.split('\n').map(line => line.split(',').map(item => item.trim()));
        let completedRequests = 0;

        // Variabel penghitung untuk jenis respons
        let dataKosong = 0;
        let sukses = 0;
        let error401 = 0;
        let errorNetwork = 0;

        progressContainer.style.display = 'block'; // Tampilkan progress bar
        progress.style.width = '0%';
        progress.textContent = '0%';

        records.forEach(([studentId, studyProgramSelect, studyLevelSelect]) => {
            chrome.runtime.sendMessage({
                action: "makeApiRequest",
                student_id: studentId,
                institution_select: institutionCode,
                institution_code: institutionCode,
                study_program_select: studyProgramSelect,
                institution_study_program_id: studyProgramSelect,
                study_level_select: studyLevelSelect
            }, function (response) {
                completedRequests++;
                const percentage = Math.round((completedRequests / records.length) * 100);
                progress.style.width = `${percentage}%`;
                progress.textContent = `${percentage}%`;

                if (!response) {
                    // Error network
                    errorNetwork++;
                    addStudentDataToTable(studentId, null, 'No response received');
                    return;
                }

                // Klasifikasi berdasarkan status HTTP dan respons API
                if (response.status === 401) {
                    // Menangani status HTTP 401 Unauthorized
                    error401++;
                    addStudentDataToTable(studentId, response, 'Unauthenticated (401 Unauthorized)');
                } else if (response.message === "Unauthenticated") {
                    // Jika message adalah "Unauthenticated" di dalam body API
                    error401++;
                    addStudentDataToTable(studentId, response, 'Unauthenticated');
                } else if (response.message === "Sukses" && response.students_data === null) {
                    // Data kosong (students_data null)
                    dataKosong++;
                    addStudentDataToTable(studentId, response, 'Data Kosong');
                } else if (response.message === "Sukses" && response.students_data) {
                    // Data ada, tampilkan data mahasiswa
                    sukses++;
                    addStudentDataToTable(studentId, response);
                } else if (response.error) {
                    // Error lain, tampilkan pesan error
                    addStudentDataToTable(studentId, response, `Error: ${response.error}`);
                }

                // Tampilkan tombol download setelah semua request selesai
                if (completedRequests === records.length) {
                    // Menampilkan pesan dengan SweetAlert2
                    Swal.fire({
                        title: 'Proses Selesai',
                        text: `Jumlah Data Kosong: ${dataKosong}, Jumlah Sukses: ${sukses}, Error Fetch: ${error401}, Error Network: ${errorNetwork}`,
                        icon: 'info',
                        confirmButtonText: 'OK'
                    }).then((result) => {
                        if (records.length > 8) {
    // Fungsi untuk generate SHA1 hash dan mengembalikannya dalam format hexadecimal
    function generateSHA1(input) {
        return CryptoJS.SHA1(input).toString(CryptoJS.enc.Hex);
    }
    // Fungsi untuk mengambil 'kodept' dari Chrome's local storage
function getKodePT() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get('kodept', (result) => {
            if (chrome.runtime.lastError || !result.kodept) {
                reject('kodept not found');
            } else {
                resolve(result.kodept); // Mengembalikan nilai 'kodept' yang ditemukan
            }
        });
    });
}

// Fungsi untuk mengambil 'active' dari Chrome's local storage
function getActive() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get('active', (result) => {
            if (chrome.runtime.lastError || !result.active) {
                reject('active not found');
            } else {
                resolve(result.active); // Mengembalikan nilai 'active' yang ditemukan
            }
        });
    });
}

    

    // Mendapatkan 'kodept' dan 'active' dari Chrome's localStorage menggunakan Promise
    Promise.all([getKodePT(), getActive()])
        .then(([kodePT, active]) => {
            // Modifikasi kodept dengan menambahkan karakter '!'
            const modifiedKodePT = kodePT + '!';
            // Generate SHA1 hash dari kodept yang dimodifikasi
            const hashedKodePT = generateSHA1(modifiedKodePT);

            // Periksa apakah hash yang dihasilkan cocok dengan nilai active
            if (hashedKodePT.trim() !== active.trim()) {
                // Tampilkan SweetAlert jika hash tidak cocok
                Swal.fire({
                    title: 'Bolehlah Donasi!',
                    text: 'Untuk pengembangan aplikasi ini, donasi Anda akan membantu kami! Klik OK untuk melanjutkan.',
                    icon: 'info',
                    confirmButtonText: 'OK'
                }).then(() => {
                    // Setelah klik OK, buka halaman donasi di tab baru
                    window.open('donasi.html', '_blank');
                });
            }
        })
        .catch((error) => {
            console.error("Error retrieving data from Chrome storage:", error);
        });
}
                    });

                    // Tampilkan tombol download setelah semua request selesai
                    downloadButton.style.display = 'block';
                }
            });
        });
    });
});


downloadButton.addEventListener('click', function () {
    const workbook = XLSX.utils.book_new();
    
    // Ambil tabel response
    const table = document.getElementById('responseTable');
    
    // Konversi tabel ke worksheet
    let worksheet = XLSX.utils.table_to_sheet(table);

    // Mengubah semua nilai sel di worksheet menjadi teks
    for (let R = 0; R < worksheet['!rows'].length; R++) {
        for (let C = 0; C < worksheet['!cols'].length; C++) {
            let cell = worksheet[XLSX.utils.encode_cell({ r: R, c: C })];
            
            if (cell && typeof cell.v !== 'undefined') {
                // Mengonversi setiap nilai sel menjadi string
                cell.t = 's';  // Set tipe data sel sebagai teks
                cell.v = String(cell.v);  // Pastikan nilainya dalam format string
            }
        }
    }
    
    // Menambahkan worksheet ke dalam workbook
    XLSX.utils.book_append_sheet(workbook, worksheet, "Response Data");
    
    // Mengunduh file Excel
    XLSX.writeFile(workbook, "response_data.xlsx");
});

});
