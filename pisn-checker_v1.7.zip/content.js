// content.js - FINAL CLEAN VERSION

// Variabel untuk mencegah spam penyimpanan data yang sama
let lastSavedDate = "";

/**
 * 1. Fungsi mengambil CSRF Token
 */
function handleCsrfToken() {
  const csrfMeta = document.querySelector('meta[name="csrf-token"]');
  if (csrfMeta) {
    const token = csrfMeta.getAttribute("content");
    
    // Simpan ke storage & kirim ke background
    chrome.storage.local.set({ csrfToken: token });
    chrome.runtime.sendMessage({ action: "setCsrfToken", csrfToken: token });
    
    // console.log("✅ CSRF Token updated."); // Uncomment jika ingin debug
  }
}

/**
 * 2. Fungsi utama mengambil Tanggal PISN
 */
function handlePisnDate() {
  // XPath Sakti: Mencari <p> yang berisi teks spesifik (tidak peduli urutan div)
  const xpath = "//p[contains(., 'Data ini bersumber dari PDDikti')]";
  
  const targetElement = document.evaluate(
    xpath,
    document,
    null,
    XPathResult.FIRST_ORDERED_NODE_TYPE,
    null
  ).singleNodeValue;

  if (targetElement) {
    const textContent = targetElement.textContent.trim();

    // Cek apakah data baru berbeda dengan yang sudah disimpan? (Agar tidak spam proses)
    if (textContent !== lastSavedDate) {
      lastSavedDate = textContent;
      
      console.log("✅ PISN EXTENSION: Data ditemukan!", textContent);

      // Simpan ke storage
      chrome.storage.local.set({ datePddikti: textContent });

      // Kirim pesan ke background & popup
      chrome.runtime.sendMessage({ action: "receivePisnHtml", data: textContent });
      chrome.runtime.sendMessage({ action: "updateUI", data: textContent });
    }
    return true;
  }
  return false;
}

/**
 * 3. Fungsi Inisialisasi Utama
 */
function initExtension() {
  handleCsrfToken();
  handlePisnDate();
}

// --- EKSEKUSI PROGRAM ---

// 1. Jalankan segera saat script dimuat
initExtension();

// 2. Jalankan saat DOM (HTML) sudah siap sepenuhnya
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initExtension);
}

// 3. Pasang "Mata-mata" (Observer) untuk menangani loading lambat/SPA
// Ini akan memantau jika ada perubahan di halaman, lalu mencoba mengambil data lagi
const observer = new MutationObserver(() => {
  // Kita coba ambil data. Jika berhasil ditemukan, kita stop observer agar hemat resource
  // Hapus "observer.disconnect()" jika halaman PISN bersifat dinamis/berubah-ubah tanpa reload
  if (handlePisnDate()) {
     // Opsional: observer.disconnect(); 
  }
});

// Mulai mengamati perubahan pada body website
observer.observe(document.body, { childList: true, subtree: true });