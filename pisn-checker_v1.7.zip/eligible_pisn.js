const MAHASISWA_PAGE = (chrome.runtime && chrome.runtime.getURL)
  ? chrome.runtime.getURL('mahasiswa_neofeeder.html')
  : 'mahasiswa_neofeeder.html';

// eligible_pisn.js (PARALEL + 3 endpoint)
let neofeederUrl = "";
let neofeederToken = "";
let institutionCode = "";

$(document).ready(function () {
  fetchStudyPrograms();

  $("#btnCheckEligible").on("click", async function () {
    const selected = [];
    $("#prodiList input[type=checkbox]:checked").each(function () {
      selected.push({
        id: $(this).data("id"),
        nama: $(this).data("nama"),
        jenjangId: $(this).data("jenjang"),
        jenjangName: $(this).data("jenjangname")
      });
    });

    if (selected.length === 0) {
      Swal.fire("Pilih minimal satu program studi.");
      return;
    }

    $("#loading").show();
    $("#loading p").text(`Memproses ${selected.length} prodi secara paralel...`);

    // Bersihkan / destroy DataTables sebelumnya
    safeDestroyTable("#eligibleTable");
    safeDestroyTable("#eligibleSummaryTable");
    safeDestroyTable("#eligibleBreakdownTable");
    $("#eligibleTable tbody").empty();
    $("#eligibleSummaryTable").remove();
    $("#eligibleBreakdownTable").remove();
    $(".__extra-tables__").remove();

    // Siapkan container tabel tambahan (dibuat via JS; HTML tidak diubah)
    const extraWrap = $(`
      <div class="__extra-tables__ mt-4">
        <h5>Ringkasan Eligible per Prodi</h5>
        <table id="eligibleSummaryTable" class="table table-bordered table-striped w-100">
          <thead>
            <tr>
              <th>Program Studi</th>
              <th>Jenjang</th>
              <th>Eligible</th>
              <th>Tidak Eligible</th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>

        <h5 class="mt-4">Breakdown Kriteria per Mahasiswa</h5>
        <table id="eligibleBreakdownTable" class="table table-bordered table-striped w-100">
          <thead>
            <tr>
              <th>NIM</th>
              <th>Nama</th>
              <th>Program Studi</th>
              <th>Lolos (eligible=1)</th>
              <th>Gagal (eligible=0)</th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>
    `);
    $("#eligibleTable").closest(".container,body").append(extraWrap);

    try {
      // Ambil CSRF token dari storage (untuk endpoint PISN)
      const csrfToken = await getCsrfToken();
      if (!csrfToken) {
        $("#loading").hide();
        Swal.fire("CSRF token tidak ditemukan. Simpan dulu csrfToken di chrome.storage.local.");
        return;
      }

      // Jalankan SEMUA prodi paralel:
      //   - getCountsPerProdi (endpoint #1)
      //   - getStudentDetailList (endpoint #2, breakdown kriteria)
      //   - fetchEligibleStudentsPromise (endpoint #3: skrip lama, takeEligibleStudent=true)
      const perProdiPromises = selected.map(prodi =>
        Promise.allSettled([
          getCountsPerProdi(prodi, csrfToken),
          getStudentDetailList(prodi, csrfToken),
          fetchEligibleStudentsPromise(prodi) // reuse fungsi lama
        ]).then(results => ({ prodi, results }))
      );

      const settled = await Promise.all(perProdiPromises);

      // Kumpulan hasil
      const summaryRows = [];
      const breakdownRows = [];
      let eligibleOnlyAll = [];

      // Gabungkan hasil tiap prodi
      for (const item of settled) {
        const [p1, p2, p3] = item.results;

        // Endpoint #1: Summary eligible/not eligible
        if (p1.status === "fulfilled" && p1.value) {
          summaryRows.push(p1.value); // {prodi, jenjang, eligible_count, not_eligible_count}
        }

        // Endpoint #2: Breakdown kriteria
        if (p2.status === "fulfilled" && Array.isArray(p2.value)) {
          breakdownRows.push(...p2.value); // {nim, nama, prodi, pass, fail}
        }

        // Endpoint #3: Eligible only (skrip lama)
        if (p3.status === "fulfilled" && Array.isArray(p3.value)) {
          eligibleOnlyAll = eligibleOnlyAll.concat(p3.value);
        }
      }

      // Render ketiga tabel
      renderSummaryTable(summaryRows);
      renderBreakdownTable(breakdownRows);
      renderTable(eligibleOnlyAll); // tabel lama (#eligibleTable), tetap dipakai

    } catch (e) {
      console.error(e);
      Swal.fire("Terjadi kesalahan saat memproses data.");
    } finally {
      $("#loading").hide();
    }
  });

  $("#btnDownloadExcel").on("click", downloadExcel);
});

/* ============================================================
 * Bagian: Ambil daftar Prodi (tetap sama)
 * ==========================================================*/
function fetchStudyPrograms() {
  chrome.storage.local.get(['url', 'username', 'password', 'kodept'], config => {
    const { url, username, password, kodept } = config;

    if (!url || !username || !password) {
      Swal.fire("Konfigurasi Neofeeder belum lengkap.");
      return;
    }

    institutionCode = kodept || "";
    neofeederUrl = url;

    // Ambil Token
    $.ajax({
      url,
      method: "POST",
      contentType: "application/json",
      data: JSON.stringify({ act: "GetToken", username, password }),
      success: res => {
        try {
          neofeederToken = res.data.token;
        } catch (e) {
          console.error("Token NeoFeeder tidak ada pada response:", res);
          Swal.fire("Gagal mendapatkan token NeoFeeder.");
          return;
        }

        // Ambil daftar prodi
        $.ajax({
          url,
          method: "POST",
          contentType: "application/json",
          data: JSON.stringify({ act: "GetProdi", token: neofeederToken }),
          success: r => {
            if (r.error_code === 0 && Array.isArray(r.data)) {
              const container = $("#prodiList");
              container.empty();

              // Urutkan berdasarkan nama_program_studi
              r.data.sort((a, b) =>
                a.nama_program_studi.localeCompare(b.nama_program_studi, 'id', { sensitivity: 'base' })
              );

              // Tampilkan daftar prodi
              r.data.forEach(p => {
                const jenjangName = mapJenjang(p.id_jenjang_pendidikan);
                container.append(`
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="prodi_${p.id_prodi}"
                      data-id="${p.id_prodi}"
                      data-nama="${escapeHtml(p.nama_program_studi)}"
                      data-jenjang="${p.id_jenjang_pendidikan}"
                      data-jenjangname="${jenjangName}">
                    <label class="form-check-label" for="prodi_${p.id_prodi}">
                      ${escapeHtml(p.nama_program_studi)} (${jenjangName})
                    </label>
                  </div>
                `);
              });
            } else {
              console.error("GetProdi error:", r);
              Swal.fire("Gagal mengambil daftar prodi dari NeoFeeder.");
            }
          },
          error: () => {
            Swal.fire("Terjadi kesalahan saat mengambil prodi dari NeoFeeder.");
          }
        });

      },
      error: () => {
        Swal.fire("Gagal mendapatkan token dari NeoFeeder.");
      }
    });
  });
}

/* ============================================================
 * Endpoint #1 : Summary Eligible / Not Eligible per prodi
 * GET ?institution_study_program_id=...&institution_code=...&study_level_pddikti_id=...
 * Response contoh: {"eligible_count":0,"not_eligible_count":11}
 * ==========================================================*/
function getCountsPerProdi(prodi, csrfToken) {
  const apiBase = "https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/list-student";
  const payload = {
    institution_study_program_id: prodi.id,
    institution_code: institutionCode,
    study_level_pddikti_id: prodi.jenjangId
  };

  return new Promise((resolve) => {
    $.ajax({
      url: apiBase,
      method: "GET",
      data: payload,
      dataType: "json",
      headers: {
        "X-CSRF-TOKEN": csrfToken,
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json, text/javascript, */*; q=0.01"
      },
      success: (res) => {
        const eligible_count = Number(res.eligible_count || 0);
        const not_eligible_count = Number(res.not_eligible_count || 0);
        resolve({
          prodi: prodi.nama,
          jenjang: prodi.jenjangName,
          eligible_count,
          not_eligible_count
        });
      },
      error: (xhr, status, err) => {
        console.error("Error summary (endpoint #1):", status, err, xhr.responseText);
        resolve({
          prodi: prodi.nama,
          jenjang: prodi.jenjangName,
          eligible_count: 0,
          not_eligible_count: 0
        });
      }
    });
  });
}

/* ============================================================
 * Endpoint #2 : DataTables full list (takeEligibleStudent=false)
 * - start/length pagination loop
 * - keluarkan nim, nama, prodi, dan 'eligible 1 apa', 'eligible 0 apa'
 * ==========================================================*/
function getStudentDetailList(prodi, csrfToken) {
  const apiBase = "https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/list-student";
  let start = 0;
  const length = 100;
  const acc = [];

  return new Promise((resolve) => {
    function fetchPage() {
      const payload = {
        draw: 1,
        'columns[0][data]': 'nim.value',
        'columns[0][name]': 'nim',
        'columns[0][searchable]': true,
        'columns[0][orderable]': false,
        'columns[0][search][value]': '',
        'columns[0][search][regex]': false,
        'columns[1][data]': 'nama_mahasiswa.value',
        'columns[1][name]': 'name',
        'columns[1][searchable]': true,
        'columns[1][orderable]': false,
        'columns[1][search][value]': '',
        'columns[1][search][regex]': false,
        'columns[2][data]': 'action',
        'columns[2][name]': 'action',
        'columns[2][searchable]': false,
        'columns[2][orderable]': false,
        'columns[2][search][value]': '',
        'columns[2][search][regex]': false,
        start: start,
        length: length,
        'search[value]': '',
        'search[regex]': false,
        institution_study_program_id: prodi.id,
        institution_code: institutionCode,
        study_level_pddikti_id: prodi.jenjangId,
        student: 1,
        takeEligibleStudent: false,
        _: Date.now()
      };

      $.ajax({
        url: apiBase,
        method: "GET",
        data: payload,
        dataType: "json",
        headers: {
          "X-CSRF-TOKEN": csrfToken,
          "X-Requested-With": "XMLHttpRequest",
          "Accept": "application/json, text/javascript, */*; q=0.01"
        },
        success: (res) => {
          const rows = Array.isArray(res.data) ? res.data : [];
          rows.forEach(m => {
  const nim  = (m.nim && m.nim.value) || (typeof m.nim === 'string' ? m.nim : "");
  const nama = (m.nama_mahasiswa && m.nama_mahasiswa.value) || (typeof m.nama_mahasiswa === 'string' ? m.nama_mahasiswa : "");

  // DARI helper baru → { pass: string[], fail: {label,value,hint}[] }
  const { pass, fail } = extractEligibilityDetails(m);

  // ⬇️ Rangkai kolom "Gagal (eligible=0)" = label + value + hint
  const failText = fail.map(f => {
    const val  = f.value || "";
    const hint = f.hint ? ` (${f.hint})` : "";
    return `${f.label}: ${val}${hint}`;
  }).join("; ");

  acc.push({
    nim,
    nama,
    prodi: prodi.nama,
    pass: pass.join(", "), // eligible=1 (label saja)
    fail: failText,        // eligible=0 (label + value + hint)
    fail_details: fail     // simpan mentah {label,value,hint} bila mau diekspor nanti
  });
});


          if (rows.length < length) {
            resolve(acc);
          } else {
            start += length;
            setTimeout(fetchPage, 100);
          }
        },
        error: (xhr, status, err) => {
          console.error("Error detail list (endpoint #2):", status, err, xhr.responseText);
          resolve(acc);
        }
      });
    }

    fetchPage();
  });
}

/* Helper BARU: ambil label untuk eligible=1, dan detail {label,value,hint} untuk eligible=0 */
function extractEligibilityDetails(row) {
  const pass = [];
  const fail = [];

  const keys = Object.keys(row || {});
  keys.forEach(k => {
    const v = row[k];
    if (v && typeof v === "object" && ("eligible" in v)) {
      const label = (typeof v.label === "string" && v.label.trim())
        ? v.label.trim()
        : normalizeKeyToLabel(k);

      const eligibleStr = String(v.eligible);
      const value = (v.value != null) ? String(v.value) : "";
      const hint = (typeof v.hint === "string") ? v.hint : "";

      if (eligibleStr === "1") {
        pass.push(label);
      } else if (eligibleStr === "0") {
        fail.push({ label, value, hint });
      }
    }
  });

  // Flag boolean di root-level (contoh: is_accredited) + hint jika tersedia
  if (typeof row.is_accredited === "boolean") {
    const hintAcc = row.akreditasi_program_studi && row.akreditasi_program_studi.hint
      ? String(row.akreditasi_program_studi.hint)
      : "";
    if (row.is_accredited) {
      pass.push("Akreditasi Program Studi");
    } else {
      fail.push({ label: "Akreditasi Program Studi", value: "false", hint: hintAcc });
    }
  }

  return { pass, fail };
}


/* Helper BARU: ambil label untuk eligible=1, dan detail {label,value,hint} untuk eligible=0 */
function extractEligibilityDetails(row) {
  const pass = [];
  const fail = [];

  const keys = Object.keys(row || {});
  keys.forEach(k => {
    const v = row[k];
    if (v && typeof v === "object" && ("eligible" in v)) {
      const label = (typeof v.label === "string" && v.label.trim())
        ? v.label.trim()
        : normalizeKeyToLabel(k);

      const eligibleStr = String(v.eligible);
      const value = (v.value != null) ? String(v.value) : "";
      const hint  = (typeof v.hint === "string") ? v.hint : "";

      if (eligibleStr === "1") {
        pass.push(label);
      } else if (eligibleStr === "0") {
        fail.push({ label, value, hint }); // ← now keeps value & hint
      }
    }
  });

  // Contoh flag boolean di root-level
  if (typeof row.is_accredited === "boolean") {
    const hintAcc = row.akreditasi_program_studi && row.akreditasi_program_studi.hint
      ? String(row.akreditasi_program_studi.hint)
      : "";
    if (row.is_accredited) {
      pass.push("Akreditasi Program Studi");
    } else {
      fail.push({ label: "Akreditasi Program Studi", value: "false", hint: hintAcc });
    }
  }

  return { pass, fail };
}


function normalizeKeyToLabel(key) {
  return String(key || "")
    .replace(/_/g, " ")
    .replace(/\s+/g, " ")
    .replace(/\b\w/g, s => s.toUpperCase())
    .trim();
}

/* ============================================================
 * Endpoint #3 : (PERSIS skrip sebelumnya) Eligible-only
 *   takeEligibleStudent=true + pagination -> renderTable(#eligibleTable)
 * ==========================================================*/
function fetchEligibleStudents(prodi, callback) {
  const apiBase = "https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/list-student";
  let start = 0;
  const length = 100;
  let all = [];

  chrome.storage.local.get(['csrfToken'], function (result) {
    const csrfToken = result.csrfToken;
    if (!csrfToken) {
      console.error("CSRF token tidak ditemukan di storage");
      callback([]);
      return;
    }
    fetchPage(csrfToken);
  });

  function fetchPage(csrfToken) {
    const payload = {
      draw: 1,
      'columns[0][data]': 'id_reg_pd',
      'columns[0][name]': 'id_reg_pd',
      'columns[0][searchable]': false,
      'columns[0][orderable]': false,
      'columns[0][search][value]': '',
      'columns[0][search][regex]': false,
      'columns[1][data]': 'nim.value',
      'columns[1][name]': 'nim',
      'columns[1][searchable]': true,
      'columns[1][orderable]': false,
      'columns[1][search][value]': '',
      'columns[1][search][regex]': false,
      'columns[2][data]': 'nama_mahasiswa.value',
      'columns[2][name]': 'name',
      'columns[2][searchable]': true,
      'columns[2][orderable]': false,
      'columns[2][search][value]': '',
      'columns[2][search][regex]': false,
      'columns[3][data]': 'action',
      'columns[3][name]': 'action',
      'columns[3][searchable]': false,
      'columns[3][orderable]': false,
      'columns[3][search][value]': '',
      'columns[3][search][regex]': false,
      start: start,
      length: length,
      'search[value]': '',
      'search[regex]': false,
      institution_study_program_id: prodi.id,
      institution_code: institutionCode,
      study_level_pddikti_id: prodi.jenjangId,
      student: 1,
      takeEligibleStudent: true,
      _: Date.now()
    };

    $.ajax({
      url: apiBase,
      method: "GET",
      data: payload,
      dataType: "json",
      headers: {
        "X-CSRF-TOKEN": csrfToken,
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json, text/javascript, */*; q=0.01"
      },
      success: function (res) {
        const rows = Array.isArray(res.data) ? res.data : [];
        const mapped = rows.map(m => ({
          id_reg_pd: m.id_reg_pd || (m.id_reg_pd && m.id_reg_pd.value) || "",
          nim: (m.nim && m.nim.value) || (typeof m.nim === 'string' ? m.nim : ""),
          nama_mahasiswa: (m.nama_mahasiswa && m.nama_mahasiswa.value) || (typeof m.nama_mahasiswa === 'string' ? m.nama_mahasiswa : ""),
          ipk: (m.ipk && m.ipk.value) || (m.ipk || ""),
          tanggal_lusus: m.tgl_keluar || (m.tgl_keluar || ""), // (biarkan sesuai datanya)
          tanggal_lulus: m.tgl_keluar || (m.tgl_keluar || ""),
          eligible_status: m.eligible_status || (m.eligible_status || ""),
          prodi: prodi.nama,
          jenjang: prodi.jenjangName
        }));

        all = all.concat(mapped);

        if (rows.length < length) {
          callback(all);
        } else {
          start += length;
          setTimeout(() => fetchPage(csrfToken), 100);
        }
      },
      error: function (xhr, status, err) {
        console.error("Error fetching PISN list-student (eligible-only):", status, err, xhr.responseText);
        callback(all);
      }
    });
  }
}

// Promise wrapper agar bisa dipakai di Promise.all
function fetchEligibleStudentsPromise(prodi) {
  return new Promise(resolve => {
    fetchEligibleStudents(prodi, data => resolve(data || []));
  });
}

/* ============================================================
 * Renderers
 * ==========================================================*/
function renderSummaryTable(rows) {
  const sel = "#eligibleSummaryTable";
  safeDestroyTable(sel);
  const $tbl = $(sel);
  const tbody = rows.map(r => `
    <tr>
      <td>${escapeHtml(r.prodi)}</td>
      <td>${escapeHtml(r.jenjang)}</td>
      <td>${r.eligible_count}</td>
      <td>${r.not_eligible_count}</td>
    </tr>
  `).join("");
  $tbl.find("tbody").html(tbody);

  $(sel).DataTable({
    pageLength: 25,
    ordering: true,
    order: [[0, 'asc']],
    lengthMenu: [10, 25, 50, 1000],
    searching: true
  });
}

function renderBreakdownTable(rows) {
  const sel = "#eligibleBreakdownTable";
  safeDestroyTable(sel);

  $(sel).DataTable({
    data: rows,
    columns: [
      {
        data: "nim",
        title: "NIM",
        render: function (data, type, row) {
          if (type !== 'display') return data; // biar sort/search tetap pakai nilai mentah
          const nim = data || '';
          const url = `${MAHASISWA_PAGE}?nim=${encodeURIComponent(nim)}`;
          return `<a href="${url}" target="_blank" rel="noopener noreferrer">${escapeHtml(nim)}</a>`;
        }
      },
      {
        data: "nama",
        title: "Nama",
        render: function (data, type, row) {
          if (type !== 'display') return data;
          const nim = row.nim || '';
          const url = `${MAHASISWA_PAGE}?nim=${encodeURIComponent(nim)}`;
          return `<a href="${url}" target="_blank" rel="noopener noreferrer">${escapeHtml(data || '')}</a>`;
        }
      },
      { data: "prodi", title: "Program Studi" },
      { data: "pass", title: "Lolos (eligible=1)" },
      { data: "fail", title: "Gagal (eligible=0)" }
    ],
    pageLength: 25,
    ordering: true,
    order: [[0, 'asc']],
    lengthMenu: [10, 25, 50, 1000],
    searching: true
  });
}


// Tabel lama (#eligibleTable) dipertahankan
function renderTable(data) {
  safeDestroyTable("#eligibleTable");
  $("#eligibleTable tbody").empty();

  $("#eligibleTable").DataTable({
    data: data,
    columns: [
      { data: "nim", title: "NIM" },
      { data: "nama_mahasiswa", title: "Nama" },
      { data: "prodi", title: "Program Studi" },
      { data: "jenjang", title: "Jenjang" },
      { data: "ipk", title: "IPK" },
      { data: "tanggal_lulus", title: "Tanggal Lulus" },
      { data: "eligible_status", title: "Status" }
    ],
    pageLength: 25,
    searching: true,
    ordering: true,
    order: [[0, 'asc']],
    lengthMenu: [10, 25, 50, 1000]
  });
}

/* ============================================================
 * Utilities
 * ==========================================================*/
function downloadExcel() {
  if (!$.fn.DataTable.isDataTable("#eligibleTable")) {
    Swal.fire("Tidak ada data untuk diunduh.");
    return;
  }
  const table = $("#eligibleTable").DataTable();
  const data = table.rows().data().toArray();
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Eligible PISN");
  XLSX.writeFile(wb, "eligible_pisn.xlsx");
}

function getCsrfToken() {
  return new Promise(resolve => {
    chrome.storage.local.get(['csrfToken'], function (result) {
      resolve(result.csrfToken || null);
    });
  });
}

function safeDestroyTable(selector) {
  if ($.fn.DataTable.isDataTable(selector)) {
    $(selector).DataTable().clear().destroy();
  }
}

function mapJenjang(id) {
  const map = {
    "20": "D1", "21": "D2", "22": "D3", "23": "D4",
    "30": "S1", "31": "Profesi", "32": "Spesialis 1",
    "33": "Spesialis 2", "34": "Subspesialis",
    "35": "S2", "36": "S2 Terapan", "40": "S3", "41": "S3 Terapan"
  };
  return map[id] || "Unknown";
}

function escapeHtml(text) {
  if (!text) return "";
  return String(text).replace(/[&<>"'`=\/]/g, function (s) {
    return ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
      '/': '&#x2F;',
      '`': '&#x60;',
      '=': '&#x3D;'
    })[s];
  });
}
