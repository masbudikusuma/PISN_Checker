let csrfToken; 

// Ambil CSRF Token
function getCsrfToken() {
    chrome.storage.local.get(['csrfToken'], function(result) {
        csrfToken = result.csrfToken;
    });
}

$(document).ready(function() {
    getCsrfToken();

    // 1. Cek Data Local Storage (Fitur Lama)
    chrome.storage.local.get(['datePddikti'], (result) => {
        if (chrome.runtime.lastError || !result.datePddikti) {
            updatePisnContent("Gagal mengambil sumber tanggal / data belum tersedia. Silahkan buka halaman PISN. ");
        } else {
            updatePisnContent(result.datePddikti);
        }
    });

    // 2. Inisialisasi DataTable
    const table = $('#table_certificate_proposal_header').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/list-header",
            type: "GET",
            dataType: "json",
            beforeSend: function(xhr) {
                xhr.setRequestHeader("X-Csrf-Token", csrfToken);
                xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
                
                if (!$('.swal2-container').length) {
                    Swal.fire({
                        title: 'Memuat data...',
                        html: 'Mohon tunggu sebentar.',
                        allowOutsideClick: false,
                        didOpen: () => Swal.showLoading()
                    });
                }
            },
            complete: function() {
                Swal.close();
                $('#select-all').prop('checked', false);
                updateDownloadButtonState();
            },
            error: function(jqXHR, textStatus, errorThrown) {
                Swal.close();
                handleAjaxError(jqXHR, textStatus, errorThrown);
            }
        },
        columns: [
            // KOLOM CHECKBOX
            {
                data: null,
                orderable: false,
                searchable: false,
                width: "5%",
                className: "text-center",
                render: function(data, type, row) {
                    // Simpan info header di atribut data agar bisa dimasukkan ke excel gabungan
                    return `<input type="checkbox" class="pisn-checkbox" 
                            value="${row.id}" 
                            data-batch="${row.batch_number}"
                            data-pt="${row.institution_name}"
                            data-prodi="${row.study_program_name}"
                            data-jenjang="${row.study_level_name}">`;
                }
            },
            { data: "batch_number", name: "batch_number" },
            { data: "institution_name", name: "i.name" },
            { data: "study_level_name", name: "sl.name" },
            { data: "study_program_name", name: "sp.name" },
            {
                data: "created_at",
                name: "created_at",
                render: function(data) {
                    return new Date(data).toLocaleDateString('id-ID', {
                        year: 'numeric', month: 'long', day: 'numeric'
                    });
                }
            },
            { data: "operator_name", name: "o.name" },
            {
                data: "action",
                orderable: false,
                searchable: false,
                render: function(data, type, row) {
                    return `<button class="btn btn-primary btn-sm detail-button" 
                        data-id="${row.id}" 
                        data-batch-number="${row.batch_number}" 
                        data-institution-name="${row.institution_name}" 
                        data-study-level-name="${row.study_level_name}" 
                        data-created_at="${row.created_at}" 
                        data-operator_name="${row.operator_name}" 
                        data-study-program-name="${row.study_program_name}">Detail</button>`;
                }
            }
        ],
        order: [[5, "desc"]]
    });

    // 3. Logic Checkbox
    $('#select-all').on('click', function() {
        $('.pisn-checkbox').prop('checked', this.checked);
        updateDownloadButtonState();
    });

    $(document).on('change', '.pisn-checkbox', function() {
        updateDownloadButtonState();
        if (!this.checked) $('#select-all').prop('checked', false);
    });

    // ==========================================
    // 4. LOGIC DOWNLOAD MERGED (GABUNGAN)
    // ==========================================
    $('#download-selected').on('click', async function() {
        const selectedCheckboxes = $('.pisn-checkbox:checked');
        const totalFiles = selectedCheckboxes.length;

        if (totalFiles === 0) return;

        // Wadah untuk menampung semua data
        let masterData = [];

        Swal.fire({
            title: 'Sedang Mengambil Data',
            html: `Memproses <b>0</b> dari <b>${totalFiles}</b> batch...`,
            allowOutsideClick: false,
            didOpen: () => Swal.showLoading()
        });

        // Loop setiap checkbox yang dipilih
        for (let i = 0; i < totalFiles; i++) {
            const checkbox = $(selectedCheckboxes[i]);
            const id = checkbox.val();
            
            // Ambil info header dari atribut checkbox untuk pelengkap data
            const infoHeader = {
                batch: checkbox.data('batch'),
                pt: checkbox.data('pt'),
                prodi: checkbox.data('prodi'),
                jenjang: checkbox.data('jenjang')
            };

            Swal.update({
                html: `Menggabungkan data batch: <b>${infoHeader.batch}</b> - ${infoHeader.prodi}<br>(${i + 1} dari ${totalFiles})`
            });

            try {
                // Ambil detail data JSON dari server
                const detailData = await fetchDetailData(id);
                
                // Format data dan masukkan ke masterData
                detailData.forEach(mhs => {
                    masterData.push({
                        "No. Batch": infoHeader.batch,
                        "Perguruan Tinggi": infoHeader.pt,
                        "Program Studi": infoHeader.prodi,
                        "Jenjang": infoHeader.jenjang,
                        "NIM": mhs.nim,
                        "Nama Mahasiswa": mhs.student_name,
                        "Nomor Ijazah": mhs.certificate_number,
                        "Tanggal Lulus": mhs.graduation_date,
                        "Keterangan": mhs.inactive_text || 'Aktif'
                    });
                });

            } catch (err) {
                console.error(`Gagal ambil ID ${id}`, err);
            }
        }

        // Generate Excel Gabungan
        if (masterData.length > 0) {
            Swal.update({ html: 'Membuat file Excel gabungan...' });
            
            // Gunakan library XLSX (xlsx.full.min.js)
            const worksheet = XLSX.utils.json_to_sheet(masterData);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Gabungan PISN");
            
            // Nama file dengan timestamp
            const timeStr = new Date().toISOString().slice(0,19).replace(/:/g,"-");
            XLSX.writeFile(workbook, `PISN_MERGED_${timeStr}.xlsx`);

            Swal.fire({
                icon: 'success',
                title: 'Selesai!',
                text: `Berhasil menggabungkan ${masterData.length} data mahasiswa dari ${totalFiles} batch.`
            });
        } else {
            Swal.fire({
                icon: 'warning',
                title: 'Data Kosong',
                text: 'Tidak ada data detail yang berhasil diambil.'
            });
        }

        // Reset
        $('.pisn-checkbox').prop('checked', false);
        $('#select-all').prop('checked', false);
        updateDownloadButtonState();
    });
});

/* =========================================
   FUNGSI - FUNGSI PENDUKUNG
   ========================================= */

// Fungsi Ajax Request Detail (Mengembalikan Promise)
function fetchDetailData(id) {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: `https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/list-detail/${id}`,
            type: "GET",
            dataType: "json",
            beforeSend: function(xhr) {
                xhr.setRequestHeader("X-Csrf-Token", csrfToken);
                xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
            },
            success: function(response) {
                // API mengembalikan object { data: [...] }
                if(response && response.data) {
                    resolve(response.data);
                } else {
                    resolve([]); // Kalau kosong return array kosong
                }
            },
            error: function(err) {
                reject(err);
            }
        });
    });
}

function updateDownloadButtonState() {
    const selectedCount = $('.pisn-checkbox:checked').length;
    $('#selected-count').text(selectedCount);
    selectedCount > 0 ? $('#download-selected').fadeIn() : $('#download-selected').fadeOut();
}

function updatePisnContent(text) {
    const targetElement = document.querySelector(".updatepddikti");
    if (targetElement) {
        targetElement.innerHTML = "";
        const newElement = document.createElement("p");
        newElement.className = "text-danger mt-2 fw-bold";
        newElement.textContent = text;
        targetElement.appendChild(newElement);
    }
}

function handleAjaxError(jqXHR, textStatus, errorThrown) {
    let errMessage = '';
    if (jqXHR.responseJSON && jqXHR.responseJSON.message === "Unauthenticated.") {
        errMessage = 'Session login PISN habis. Silakan login ulang.';
    } else {
        errMessage = 'Terjadi kesalahan koneksi atau server.';
    }
    Swal.fire({ icon: 'error', title: 'Oops...', text: errMessage });
}

// =========================================
// LOGIC MODAL DETAIL (FITUR LAMA)
// =========================================
$(document).on('click', '.detail-button', function() {
    const d = $(this).data();
    showDetailModal(d.id, d.batchNumber, d.institutionName, d.studyLevelName, d.studyProgramName, d.createdAt, d.operator_name);
});

function showDetailModal(id, batch, pt, level, prodi, date, operator) {
    Swal.fire({
        title: 'Detail Sertifikat',
        width: '80%',
        html: `  
        <div id="modal-content" class="text-start" style="font-size: 14px;"> 
            <div class="row mb-3">
                <div class="col-6">
                    <strong>Batch:</strong> ${batch}<br>
                    <strong>PT:</strong> ${pt}<br>
                    <strong>Jenjang:</strong> ${level}
                </div>
                <div class="col-6">
                    <strong>Prodi:</strong> ${prodi}<br>
                    <strong>Tanggal:</strong> ${date}<br>
                    <strong>Oleh:</strong> ${operator}
                </div>
            </div>
            <table class="table table-bordered table-sm" id="table_detail_modal">
                <thead class="table-light">
                    <tr><th>NIM</th><th>Nama</th><th>No. Ijazah</th><th>Tgl Lulus</th><th>Ket</th></tr>
                </thead>
                <tbody></tbody>
            </table>
            <button onclick="downloadSingleExcel('${id}', '${prodi}', '${batch}')" class="btn btn-success mt-2">Download Ini Saja</button>
        </div>`,
        showConfirmButton: true,
        confirmButtonText: 'Tutup',
        willOpen: () => {
            Swal.showLoading();
            fetchDetailData(id).then(data => {
                Swal.hideLoading();
                let rows = '';
                data.forEach(item => {
                    rows += `<tr>
                        <td>${item.nim}</td><td>${item.student_name}</td>
                        <td>${item.certificate_number}</td><td>${item.graduation_date}</td>
                        <td>${item.inactive_text || ''}</td>
                    </tr>`;
                });
                $('#table_detail_modal tbody').html(rows);
            }).catch(() => {
                Swal.hideLoading();
                $('#table_detail_modal tbody').html('<tr><td colspan="5" class="text-center text-danger">Gagal mengambil data</td></tr>');
            });
        }
    });
}

// Fungsi download single (tombol di dalam modal)
window.downloadSingleExcel = function(id, prodi, batch) {
    const fileName = `${prodi}_${batch}.xlsx`;
    Swal.fire({ title: 'Downloading...', didOpen: () => Swal.showLoading() });
    
    $.ajax({
        url: 'https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/export-student',
        type: 'POST',
        headers: { "X-Csrf-Token": csrfToken, "X-Requested-With": "XMLHttpRequest" },
        data: { certificateProposalId: id },
        xhrFields: { responseType: 'blob' },
        success: function(blob) {
            const link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            link.download = fileName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            Swal.close();
        },
        error: function() {
            Swal.fire('Error', 'Gagal download file', 'error');
        }
    });
};