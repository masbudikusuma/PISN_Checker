$(document).ready(function() {
  // --- BAGIAN 1: Mengambil Data PISN dari Storage ---
  
  chrome.storage.local.get(['datePddikti'], (result) => {
    // Cek jika ada error dari Chrome itu sendiri
    if (chrome.runtime.lastError) {
      console.error("Storage Error:", chrome.runtime.lastError);
      updatePisnContent("Gagal mengambil data storage.");
      return;
    }

    // Cek apakah data PISN ada isinya
    if (result && result.datePddikti) {
      console.log("PISN Data ditemukan:", result.datePddikti);
      updatePisnContent(result.datePddikti);
    } else {
      // Jika tidak ada data (bukan error, tapi belum tersimpan)
      console.warn("Data PISN belum tersimpan di local storage.");
      updatePisnContent("Data belum tersedia. Silakan buka halaman PISN.");
    }
  });

  // Fungsi untuk memperbarui konten di halaman (Diperbaiki)
  function updatePisnContent(text) {
    const targetElement = document.querySelector(".updatepddikti");
    
    if (targetElement) {
      // PERBAIKAN: Kosongkan elemen target dulu agar teks tidak menumpuk
      targetElement.innerHTML = ''; 

      // Tambahkan teks di bawah elemen target
      const newElement = document.createElement("p");
      const strongElement = document.createElement("strong");
      
      strongElement.textContent = text;
      newElement.appendChild(strongElement); 
      newElement.className = "text-danger mt-2"; 
      
      targetElement.appendChild(newElement);
    } else {
      console.error("Target element (.updatepddikti) not found in popup HTML!");
    }
  }
});

// --- BAGIAN 2: Generate Prodi (Logic Asli Dipertahankan) ---

document.getElementById('generateProdiBtn').addEventListener('click', function() {
  const nimInputElement = document.getElementById('nimInput');
  if (!nimInputElement) {
    console.error('Element with id "nimInput" not found.');
    return;
  }

  const nimInput = nimInputElement.value.trim();
  const records = nimInput.split('\n').map(item => item.trim()).filter(item => item);

  if (records.length === 0) {
    alert('Silakan masukkan NIM terlebih dahulu!');
    return;
  }

  // Resetkan data tabel
  const responseBody = document.getElementById('responseBody');
  if (responseBody) responseBody.innerHTML = '';

  // Ambil data konfigurasi dari storage
  chrome.storage.local.get(['url', 'username', 'password', 'kodept'], (result) => {
    const url = result.url;
    const username = result.username;
    const password = result.password;
    const institutionCode = result.kodept;

    if (!institutionCode) {
      console.error('Institution code (kodept) not found.');
      alert('Kode PT tidak ditemukan dalam storage. Lakukan pengaturan pada menu Konfigurasi Neofeeder');
      return;
    }

    let token = null;

    // Fungsi mendapatkan token
    function getToken(callback) {
      $.ajax({
        url: url,
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
          act: 'GetToken',
          username: username,
          password: password
        }),
        success: (response) => {
          if (response && response.data && response.data.token) {
            token = response.data.token;
            callback(token);
          } else {
            alert("Gagal mendapatkan Token dari Neofeeder.");
          }
        },
        error: (xhr, status, error) => {
          console.error('Error getting token:', error);
          alert('Terjadi kesalahan koneksi saat mengambil token.');
        }
      });
    }

    // Fungsi mendapatkan data mahasiswa
    function getMahasiswa(token, nim) {
      $.ajax({
        url: url,
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
          act: 'GetListMahasiswa',
          token: token,
          filter: `nim='${nim}'`
        }),
        success: (response) => {
          // Cek validitas response
          if (!response || !response.data) {
             console.warn(`Data kosong untuk NIM ${nim}`);
             return;
          }

          const data = response.data[0];
          const nimTextArea = document.getElementById('nimInput');
          const currentContent = nimTextArea.value.trim();
          let newContent = currentContent;

          if (data) {
            let programCode = 'Unknown';
            const prodi = data.nama_program_studi || "";

            if (prodi.includes('S1')) programCode = '30';
            else if (prodi.includes('S2')) programCode = '35';
            else if (prodi.includes('S3')) programCode = '40';
            else if (prodi.includes('D1')) programCode = '20';
            else if (prodi.includes('D2')) programCode = '21';
            else if (prodi.includes('D3')) programCode = '22';
            else if (prodi.includes('D4')) programCode = '23';
            else if (prodi.includes('Profesi')) programCode = '31';
            else if (prodi.includes('Sp-1')) programCode = '32';
            else if (prodi.includes('S2 Terapan')) programCode = '36';
            else if (prodi.includes('S3 Terapan')) programCode = '41';

            const formattedData = `${data.nipd},${data.id_sms},${programCode}`;
            const regex = new RegExp(`^${nim}.*`, 'm');
            newContent = currentContent.replace(regex, formattedData);
          } else {
            const notFoundMessage = `${nim}, tidak ditemukan`;
            const regex = new RegExp(`^${nim}.*`, 'm');
            newContent = currentContent.replace(regex, notFoundMessage);
          }

          document.getElementById('nimInput').value = newContent;
        },
        error: (xhr, status, error) => {
          console.error(`Error fetching mahasiswa ${nim}:`, error);
        }
      });
    }

    // Eksekusi utama
    if (!token) {
      getToken((newToken) => {
        token = newToken;
        records.forEach(nim => getMahasiswa(token, nim));
      });
    } else {
      records.forEach(nim => getMahasiswa(token, nim));
    }
  });
});

// --- BAGIAN 3: Form Submit (Logic Asli Dipertahankan) ---

const apiForm = document.getElementById('apiForm');
if (apiForm) {
  apiForm.addEventListener('submit', function (event) {
    event.preventDefault();

    chrome.storage.local.get(['kodept'], (result) => {
      const institutionCode = result.kodept;

      if (!institutionCode) {
        alert('Kode PT tidak ditemukan dalam storage.');
        return;
      }

      const nimProdiInputElement = document.getElementById('nimInput');
      if (!nimProdiInputElement) return;

      const nimProdiInput = nimProdiInputElement.value.trim();
      const progress = document.getElementById('progress-bar');
      const responseError = document.getElementById('responseError');
      const downloadButton = document.getElementById('downloadButton');

      responseError.textContent = '';
      downloadButton.style.display = 'none';
      progress.style.width = '0%';
      progress.textContent = '0%';

      // Filter baris kosong agar tidak error saat request
      const records = nimProdiInput.split('\n').filter(line => line.trim() !== ""); 
      let completedRequests = 0;

      if (records.length === 0) {
        alert("Tidak ada data untuk diproses.");
        return;
      }

      records.forEach((record) => {
        const parts = record.split(',').map(item => item.trim());
        // Validasi format data (harus ada 3 bagian: NIM, ID SMS, Jenjang)
        if (parts.length < 3) {
           completedRequests++;
           responseError.textContent += `Format salah pada baris: ${record}\n`;
           return;
        }

        const [studentId, studyProgramSelect, studyLevelSelect] = parts;

        chrome.runtime.sendMessage({
          action: "makeApiRequest",
          student_id: studentId,
          institution_select: institutionCode,
          institution_code: institutionCode,
          study_program_select: studyProgramSelect,
          institution_study_program_id: studyProgramSelect,
          study_level_select: studyLevelSelect
        }, function (response) {
          completedRequests++;
          
          // Update Progress Bar
          const percentage = Math.round((completedRequests / records.length) * 100);
          progress.style.width = `${percentage}%`;
          progress.textContent = `${percentage}%`;

          if (!response) {
            responseError.textContent += `No response received for NIM ${studentId}.\n`;
          } else if (response.error) {
            responseError.textContent += `Error for NIM ${studentId}: ${response.error}\n`;
          } else {
             // Pastikan fungsi ini ada di file lain atau scope global
             if (typeof addStudentDataToTable === "function") {
                addStudentDataToTable(studentId, response);
             } else {
                console.warn("Fungsi addStudentDataToTable tidak ditemukan.");
             }
          }

          if (completedRequests === records.length) {
            downloadButton.style.display = "block";
          }
        });
      });
    });
  });
}