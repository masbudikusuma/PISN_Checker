let csrfToken = ""; 

chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL('tentang.html') });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  
  // 1. Menangani Token CSRF
  if (request.action === "setCsrfToken") {
    csrfToken = request.csrfToken;
    // Simpan juga ke storage agar persisten
    chrome.storage.local.set({ csrfToken: csrfToken });
    console.log("X-Csrf-Token saved:", csrfToken);
    return true; 
  }

  // 2. Menangani Data Tanggal PISN (Tambahan Baru)
  // Ini penting agar pesan dari content.js tidak dianggap "error"
  if (request.action === "receivePisnHtml") {
    console.log("Background menerima data PISN:", request.data);
    // Backup simpan ke storage via background (safety net)
    chrome.storage.local.set({ datePddikti: request.data });
    return true;
  }

  // 3. Menangani Request API (Proxy)
  if (request.action === "makeApiRequest") {
    chrome.storage.local.get(['csrfToken'], (result) => {
      // Prioritaskan token dari storage, lalu variabel global, lalu default
      const tokenToUse = result.csrfToken || csrfToken || "default-token";
      console.log("Making Request with Token:", tokenToUse);

      const url = "https://pisn.kemdiktisaintek.go.id/operator/check-eligibility/search";
      const headers = {
        "X-Csrf-Token": tokenToUse,
        "X-Requested-With": "XMLHttpRequest",
        "Content-Type": "application/x-www-form-urlencoded",
        // Hapus Sec-Fetch-Mode jika bikin error, tapi biasanya oke
      };

      const body = new URLSearchParams({
        method: "input",
        institution_select: request.institution_select,
        study_level_select: request.study_level_select,
        study_program_select: request.study_program_select,
        student_id: request.student_id,
        proengsoft_jsvalidation: "",
        institution_study_program_id: request.institution_study_program_id,
        institution_code: request.institution_code
      });

      fetch(url, {
        method: "POST",
        headers: headers,
        body: body,
      })
      .then(response => {
        if (response.status === 401) throw new Error("Unauthenticated");
        if (!response.ok) throw new Error("Network error: " + response.statusText);
        return response.json();
      })
      .then(data => sendResponse(data))
      .catch(error => {
        console.error("API Error:", error);
        sendResponse({ error: error.message });
      });
    });
    return true; // Async response
  }

  // 4. Menangani Token Neofeeder
  if (request.action === "getTokenNeofeeder") {
    fetch(request.url, {
      method: request.method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request.payload)
    })
    .then(res => res.json())
    .then(data => sendResponse({ data }))
    .catch(error => sendResponse({ error: error.message }));
    return true;
  }

  // 5. Menangani API Neofeeder
  if (request.action === "apiNeofeeder") {
    fetch(request.url, {
      method: request.method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request.payload)
    })
    .then(res => res.json())
    .then(data => sendResponse({ data }))
    .catch(error => sendResponse({ error: error.message }));
    return true;
  }
});

chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL("tentang.html") });
});