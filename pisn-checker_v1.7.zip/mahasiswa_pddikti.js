document.addEventListener("DOMContentLoaded", async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const nim = urlParams.get("nim");
    const id = urlParams.get("id");

    const formContainer = document.querySelector(".form-container");
    const resultContainer = document.getElementById("result");
    const hasilpencarian = document.getElementById("hasilpencarian");
    const aktivitasContainer = document.getElementById("aktivitasContainer");
    const nilaiContainer = document.getElementById("nilaiContainer");
    const loadingSpinner = document.getElementById("loadingSpinner");

    // Hide containers initially
    aktivitasContainer.style.display = "none";
    nilaiContainer.style.display = "none";

    // Helper function to get data from Chrome local storage
    const getChromeStorageData = (key) =>
        new Promise((resolve) => {
            chrome.storage.local.get(key, (result) => resolve(result[key]));
        });

    if (nim) {
    // Case: URL has `nim` parameter (Search student)
    formContainer.style.display = "none";
    loadingSpinner.style.display = "block";

    const i_idunit = await getChromeStorageData("i_idunit");
    const pm = await getChromeStorageData("pm");

    const payload = new URLSearchParams({
        "data[keyword]": nim,
        "data[id_sp]": i_idunit,
        "data[id_sms]": "",
        "data[vld]": "0",
    });

    try {
        const response = await fetch(
            `https://api-pddikti-admin.kemdikbud.go.id/mahasiswa/result?page=0&pm=${pm}&limit=20`,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    Accept: "application/json",
                },
                body: payload.toString(),
            }
        );

        const data = await response.json();
        loadingSpinner.style.display = "none";

        if (data.result && data.result.data.length > 0) {
            const results = data.result.data;

            // Jika hanya ada satu record, langsung redirect
            if (results.length === 1) {
                const mahasiswa = results[0];
                window.location.href = `mahasiswa_pddikti.html?id=${mahasiswa.id_reg_pd}`;
                return; // Hentikan eksekusi lebih lanjut
            }

            // Generate table untuk menampilkan daftar hasil jika lebih dari satu record
            let tableRows = results
                .map(
                    (mahasiswa) => `
                    <tr>
                        <td>
                            <a href="mahasiswa_pddikti.html?id=${mahasiswa.id_reg_pd}">${mahasiswa.nm_pd}</a>
                        </td>
                        <td>
                            <a href="mahasiswa_pddikti.html?id=${mahasiswa.id_reg_pd}">${mahasiswa.nipd}</a>
                        </td>
                        <td>${mahasiswa.namaprodi}</td>
                        <td>${mahasiswa.namajenjang}</td>
                        <td>${mahasiswa.namapt}</td>
                        <td>${mahasiswa.ket_keluar}</td>
                    </tr>
                `
                )
                .join("");

            hasilpencarian.innerHTML = `
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>NIM</th>
                            <th>Program Studi</th>
                            <th>Jenjang</th>
                            <th>PT</th>
                            <th>Keterangan Keluar</th>
                        </tr>
                    </thead>
                    <tbody>${tableRows}</tbody>
                </table>
            `;
        } else {
            hasilpencarian.innerHTML = `<p class="text-danger">Data tidak ditemukan.</p>`;
        }
    } catch (error) {
        loadingSpinner.style.display = "none";
        hasilpencarian.innerHTML = `<p class="text-danger">Terjadi kesalahan saat mengambil data.</p><p class="text-danger">Coba ulangi <a href="neofeeder.html"  target="a_blank">Konfigurasi Neofeeder</a>. Lalu <a href="pddikti.html" target="a_blank">Cek Koneksi PDDIKTI</a></p>`;
        console.error(error);
    }
}
 else if (id) {
        // Case: URL has `id` parameter (Show student details)
        formContainer.style.display = "none";
        loadingSpinner.style.display = "block";

        const pm = await getChromeStorageData("pm");

        try {
            const response = await fetch(
                `https://api-pddikti-admin.kemdikbud.go.id/mahasiswa/detail/${id}?pm=${pm}`,
                {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                        Accept: "application/json",
                    },
                }
            );

            const data = await response.json();
            loadingSpinner.style.display = "none";

            if (data.result) {
                const { dataumum, datakuliah, datakhs } = data.result;

                // Display "dataumum"
                resultContainer.innerHTML = `
                    <h4>Profil Mahasiswa</h4>
                    <p>NIM: ${dataumum.nipd}</p>
                    <p>Status: ${dataumum.stat_pd}</p>
                    <p>Nama: ${dataumum.nm_pd}</p>
                    <p>Jenjang: ${dataumum.namajenjang}</p>
                    <p>Prodi: ${dataumum.namaprodi}</p>
                    <p>PT: ${dataumum.namapt}</p>

                    <p>Tanggal Lahir: ${dataumum.tgl_lahir}</p>
                    <p>Tempat Lahir: ${dataumum.tmpt_lahir}</p>
                    <p>NIK: ${dataumum.nik}</p>
                    
                    <p>Jenis Daftar: ${dataumum.mulai_smt}</p>
                    <p>Jenis Daftar: ${dataumum.nm_jns_daftar}</p>
                    <p>Tanggal masuk: ${dataumum.tgl_masuk_sp}</p>
                    <p>No Ijazah: ${dataumum.no_seri_ijazah}</p>
                    <p>IPK: ${dataumum.ipk}</p>
                    <p>Tanggal Keluar: ${dataumum.tgl_keluar}</p>
                    <p>Keterangan Keluar: ${dataumum.ket_keluar}</p>
                `;

                // Display "datakuliah" (AKM)
                aktivitasContainer.style.display = "block";
                const aktivitasTableBody = document.querySelector("#aktivitasTable tbody");
                datakuliah.forEach((item) => {
                    aktivitasTableBody.innerHTML += `
                        <tr>
                            <td>${item.id_smt}</td>
                            <td>${dataumum.nipd}</td>
                            <td>${item.ips}</td>
                            <td>${item.ipke}</td>
                            <td>${item.sks_smt}</td>
                            <td>${item.sks_total}</td>
                            <td>${item.nm_stat_mhs.trim()}</td>
                        </tr>
                    `;
                });

                // Display "datakhs"
                nilaiContainer.style.display = "block";
                const nilaiTableBody = document.querySelector("#nilaiTable tbody");
                datakhs.forEach((item) => {
                    nilaiTableBody.innerHTML += `
                        <tr>
                            <td>${item.id_smt}</td>
                            <td>${item.nm_mk}</td>
                            <td>${item.kode_mk}</td>
                            <td>${item.sks_mk}</td>
                            <td>${item.nilai_angka}</td>
                            <td>${item.nilai_huruf.trim()}</td>
                            <td>${item.nilai_indeks}</td>
                        </tr>
                    `;
                });
            } else {
                resultContainer.innerHTML = `<p class="text-danger">Data tidak ditemukan.</p>`;
            }
        } catch (error) {
            loadingSpinner.style.display = "none";
            resultContainer.innerHTML = `<p class="text-danger">Terjadi kesalahan saat mengambil data.</p>Coba ulangi <a href="neofeeder.html"  target="a_blank">Konfigurasi Neofeeder</a>. Lalu <a href="pddikti.html" target="a_blank">Cek Koneksi PDDIKTI</a>`;
            console.error(error);
        }
    }
});


  document.addEventListener('DOMContentLoaded', function () {
        // Tangkap event submit form
        const form = document.getElementById('cekMahasiswaForm');
        if (form) {
            form.addEventListener('submit', function (event) {
                event.preventDefault(); // Mencegah perilaku default form

                // Ambil nilai input NIM
                const nim = document.getElementById('nim').value.trim();

                // Redirect ke URL tujuan dengan parameter NIM
                if (nim) {
                    window.location.href = `mahasiswa_pddikti.html?nim=${encodeURIComponent(nim)}`;
                } else {
                    alert('Silakan masukkan NIM mahasiswa!');
                }
            });
        } else {
            console.error("Form dengan ID 'cekMahasiswaForm' tidak ditemukan.");
        }
    });