document.getElementById('apiForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const institutionCode = document.getElementById('institutionCode').value;
    const nimProdiInput = document.getElementById('nimProdi').value.trim();
    const progress = document.getElementById('progress-bar');
    const responseError = document.getElementById('responseError');
    const downloadButton = document.getElementById('downloadButton');

    responseError.textContent = '';
    downloadButton.style.display = 'none';
    progress.style.width = '0%';
    progress.textContent = '0%';

    const records = nimProdiInput.split('\n'); // Split berdasarkan baris baru
    let completedRequests = 0;

    records.forEach((record, index) => {
        const [studentId, studyProgramSelect, studyLevelSelect] = record.split(',').map(item => item.trim());

        chrome.runtime.sendMessage({
            action: "makeApiRequest",
            student_id: studentId,
            institution_select: institutionCode,
            institution_code: institutionCode,
            study_program_select: studyProgramSelect,
            institution_study_program_id: studyProgramSelect,
            study_level_select: studyLevelSelect // Tambahkan kode_jenjang
        }, function (response) {
            completedRequests++;
            progress.style.width = `${(completedRequests / records.length) * 100}%`;
            progress.textContent = `${Math.round((completedRequests / records.length) * 100)}%`;

            if (!response) {
                responseError.textContent += `No response received for NIM ${studentId}.\n`;
                return;
            }

            if (response.error) {
                responseError.textContent += `Error for NIM ${studentId}: ${response.error}\n`;
            } else {
                addStudentDataToTable(studentId, response);
            }

            // Memeriksa jika semua request selesai
            if (completedRequests === records.length) {
                downloadButton.style.display = "block";
            }
        });
    });
});
