// mahasiswa_neofeeder.js
$(document).ready(() => {
  // Variabel global
  let globalUrl = '';
  let globalToken = '';

  // Helper: ambil query param
  function getUrlParameter(name) {
    const results = new RegExp('[?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (results == null) return null;
    return decodeURIComponent(results[1]) || null;
  }

  // Detail Mahasiswa Lulus/DO
  function getDetailMahasiswaLulusDO(nim) {
    if (!globalUrl || !globalToken) {
      alert('Konfigurasi URL/token belum siap.');
      return;
    }
    $.ajax({
      url: globalUrl,
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({
        act: 'GetDetailMahasiswaLulusDO',
        token: globalToken,
        filter: `nim='${nim}'`
      }),
      success: (response) => {
        const detail = (response && response.data && response.data[0]) || null;
        if (!detail) { Swal.fire('Info','Data detail tidak ditemukan','info'); return; }
        const detailHtml = `
          <div><strong>NIM:</strong> ${detail.nim ?? '-'}</div>
          <div><strong>Nama Mahasiswa:</strong> ${detail.nama_mahasiswa ?? '-'}</div>
          <div><strong>Angkatan:</strong> ${detail.angkatan ?? '-'}</div>
          <div><strong>Jenis Keluar:</strong> ${detail.nama_jenis_keluar ?? '-'}</div>
          <div><strong>Tanggal Keluar:</strong> ${detail.tanggal_keluar ?? '-'}</div>
          <div><strong>Keterangan:</strong> ${detail.keterangan ?? '-'}</div>
          <div><strong>Nomor SK Yudisium:</strong> ${detail.nomor_sk_yudisium ?? '-'}</div>
          <div><strong>Tanggal SK Yudisium:</strong> ${detail.tanggal_sk_yudisium ?? '-'}</div>
          <div><strong>IPK:</strong> ${detail.ipk ?? '-'}</div>
          <div><strong>Nomor Ijazah:</strong> ${detail.nomor_ijazah ?? '-'}</div>
          <div><strong>Judul Skripsi:</strong> ${detail.judul_skripsi ?? '-'}</div>
          <div><strong>Asal Ijazah:</strong> ${detail.asal_ijazah ?? '-'}</div>
          <div><strong>Periode Keluar:</strong> ${detail.id_periode_keluar ?? '-'}</div>
        `;
        $('#modalDetailBody').html(detailHtml);
        const modal = new bootstrap.Modal(document.getElementById('detailModal'));
        modal.show();
      },
      error: (_, _s, err) => {
        console.error('Error detail:', err);
        Swal.fire('Error','Gagal mengambil detail mahasiswa','error');
      }
    });
  }

  // Proses NIM → ambil config & token → load data
  function processNIM(nim) {
    if (!nim) { Swal.fire('Perhatian','Mohon isi NIM terlebih dahulu','warning'); return; }

    chrome.storage?.local?.get(['url', 'username', 'password'], (result) => {
      const url = result?.url || '';
      const username = result?.username || '';
      const password = result?.password || '';

      if (!url || !username || !password) {
        Swal.fire('Konfigurasi belum lengkap','Silakan set url/username/password di opsi ekstensi','warning');
        return;
      }

      globalUrl = url;

      function getToken(cb) {
        $.ajax({
          url,
          method: 'POST',
          contentType: 'application/json',
          data: JSON.stringify({ act:'GetToken', username, password }),
          success: (res) => {
            const tok = res?.data?.token || '';
            if (!tok) { Swal.fire('Error','Token kosong','error'); return; }
            globalToken = tok;
            cb(tok);
          },
          error: (_, _s, err) => {
            console.error('Error token:', err);
            Swal.fire('Error','Gagal mendapatkan token','error');
          }
        });
      }

      function getMahasiswa(token) {
        $.ajax({
          url,
          method: 'POST',
          contentType: 'application/json',
          data: JSON.stringify({
            act: 'GetDataLengkapMahasiswaProdi',
            token,
            filter: `nim='${nim}'`
          }),
          success: (res) => {
            const data = res?.data?.[0];
            if (!data) { Swal.fire('Info','Data mahasiswa tidak ditemukan','info'); return; }

            const nikColor = (data.nik && data.nik.length === 16) ? 'green' : 'red';
            const nikLengthText = data.nik ? `Jumlah Karakter: ${data.nik.length}` : 'NIK tidak tersedia';

            const html = `
              <div class="col-md-16"><strong>ID Reg:</strong><br>${data.id_registrasi_mahasiswa ?? '-'}</div>
              <div class="col-md-16"><strong>ID Prodi:</strong><br>${data.id_prodi ?? '-'}</div>
              <div class="col-md-16"><strong>NIM:</strong> ${data.nim ?? '-'}</div>
              <div class="col-md-16">
                <strong>NIK:</strong> ${data.nik ?? '-'}
                <span style="color:${nikColor};font-weight:bold;margin-left:10px;">(${nikLengthText})</span>
              </div>
              <div class="col-md-16"><strong>Nama Mahasiswa:</strong> ${data.nama_mahasiswa ?? '-'}</div>
              <div class="col-md-16"><strong>Jenis Kelamin:</strong> ${data.jenis_kelamin ?? '-'}</div>
              <div class="col-md-16"><strong>Tanggal Lahir:</strong> ${data.tanggal_lahir ?? '-'}</div>
              <div class="col-md-16"><strong>Program Studi:</strong> ${data.nama_program_studi ?? '-'}</div>
              <div class="col-md-16">
                <strong>Status Mahasiswa:</strong> ${data.nama_status_mahasiswa ?? '-'}
                ${['AKTIF','CUTI','NON-AKTIF'].includes((data.nama_status_mahasiswa||'').trim()) ? '' : `
                  <button class="btn btn-info btn-sm detail-btn" data-nim="${nim}">Lihat Detail</button>`
                }
              </div>
              <div class="col-md-16"><strong>Periode Masuk:</strong> ${data.id_periode_masuk ?? '-'}</div>
            `;
            $('#result').html(html);
            $('#nim').val(nim);

            getAktivitasKuliah(token, nim);
            getRiwayatNilaiMahasiswa(token, nim);
          },
          error: (_, _s, err) => {
            console.error('Error mahasiswa:', err);
            Swal.fire('Error','Gagal mengambil data mahasiswa','error');
          }
        });
      }

      function getAktivitasKuliah(token, nim) {
        $.ajax({
          url,
          method: 'POST',
          contentType: 'application/json',
          data: JSON.stringify({
            act: 'GetAktivitasKuliahMahasiswa',
            token,
            filter: `nim='${nim}'`,
            order: 'id_semester'
          }),
          success: (res) => {
            const list = res?.data || [];
            if (!list.length) { $('#aktivitasContainer').hide(); return; }

            let rows = '';
            let totalSKS = 0;
            list.forEach(item => {
              const sksSmt = parseInt(item.sks_semester, 10) || 0;
              totalSKS += sksSmt;
              const syncText = (item.status_sync || '').replace(' sync','');
              rows += `
                <tr>
                  <td>${item.id_semester ?? '-'}</td>
                  <td>${item.nim ?? '-'}</td>
                  <td>${item.ips ?? '-'}</td>
                  <td>${item.ipk ?? '-'}</td>
                  <td>${item.sks_semester ?? '-'}</td>
                  <td>${item.sks_total ?? '-'}</td>
                  <td>${(item.biaya_kuliah_smt || '').toString().replace('.00','')}</td>
                  <td>${item.nama_status_mahasiswa ?? '-'}</td>
                  <td style="color:${syncText === 'belum' ? 'red' : 'inherit'}">${syncText}</td>
                </tr>`;
            });

            rows += `
              <tr>
                <td colspan="4" class="text-end"><b>Total SKS Semester:</b></td>
                <td><b>${totalSKS}</b></td>
                <td class="text-start"><small>&larr; sbg dasar PISN</small></td>
                <td colspan="3"></td>
              </tr>`;

            $('#aktivitasTable tbody').html(rows);
            $('#aktivitasContainer').show();
          },
          error: (_, _s, err) => {
            console.error('Error aktivitas:', err);
            Swal.fire('Error','Gagal mengambil aktivitas kuliah','error');
          }
        });
      }

      function getRiwayatNilaiMahasiswa(token, nim) {
        $('#loadingSpinner').show();
        $('#nilaiContainer').hide();
        $('#nilaiTable tbody').empty();
        $('#nilaiTableFoot').empty();
        $('#rekapPerPeriode').empty();

        $.ajax({
          url,
          method: 'POST',
          contentType: 'application/json',
          data: JSON.stringify({
            act: 'GetRiwayatNilaiMahasiswa',
            token,
            filter: `nim='${nim}'`,
            order: 'id_periode'
          }),
          success: (res) => {
            const list = res?.data || [];
            if (!list.length) { $('#nilaiContainer').hide(); return; }

            let rows = '';
            let totalSKS = 0;
            const sksPerPeriode = new Map(); // id_periode -> total SKS

            list.forEach(item => {
              const sks = parseInt(item.sks_mata_kuliah, 10) || 0;
              totalSKS += sks;

              const periode = item.id_periode ?? '-';
              sksPerPeriode.set(periode, (sksPerPeriode.get(periode) || 0) + sks);

              rows += `
                <tr>
                  <td>${periode}</td>
                  <td>${item.nama_mata_kuliah ?? '-'}</td>
                  <td>${item.nama_kelas_kuliah ?? '-'}</td>
                  <td>${sks}</td>
                  <td>${item.nilai_angka ?? '-'}</td>
                  <td>${item.nilai_huruf ?? '-'}</td>
                  <td>${item.nilai_indeks ?? '-'}</td>
                </tr>`;
            });

            $('#nilaiTable tbody').html(rows);

            // --- RINGKASAN DI BARIS TERAKHIR (tfoot) ---
            const jumlahPeriodeUnik = Array.from(sksPerPeriode.keys())
              .filter(k => k && k !== '-').length;

            const footHtml = `
              <tr>
                <td colspan="3" class="text-end"><b>Jumlah SKS Ditempuh (Total):</b></td>
                <td><b>${totalSKS}</b></td>
                <td colspan="3"></td>
              </tr>
              <tr>
                <td colspan="4" class="text-end"><b>Jumlah id_periode Unik:</b></td>
                <td><b>${jumlahPeriodeUnik}</b></td>
                <td colspan="2"></td>
              </tr>`;
            $('#nilaiTableFoot').html(footHtml);

            // --- REKAP PER ID_PERIODE (tabel kecil di bawahnya) ---
            const rekapRows = Array.from(sksPerPeriode.entries())
              .sort((a,b) => String(a[0]).localeCompare(String(b[0])))
              .map(([periode, sks]) => `
                <tr>
                  <td>${periode}</td>
                  <td>${sks}</td>
                </tr>
              `).join('');

            const rekapTable = `
              <div class="card">
                <div class="card-body">
                  <h6 class="mb-2">Rekap SKS per ID Periode</h6>
                  <table class="table table-sm">
                    <thead><tr><th>ID Periode</th><th>Total SKS</th></tr></thead>
                    <tbody>${rekapRows}</tbody>
                  </table>
                </div>
              </div>`;
            $('#rekapPerPeriode').html(rekapTable);

            $('#nilaiContainer').show();
          },
          error: (_, _s, err) => {
            console.error('Error nilai:', err);
            Swal.fire('Error','Gagal mengambil riwayat nilai','error');
          },
          complete: () => { $('#loadingSpinner').hide(); }
        });
      }

      getToken((tok) => getMahasiswa(tok));
    });
  }

  // Submit form
  $('#cekMahasiswaForm').on('submit', (e) => {
    e.preventDefault();
    processNIM( ($('#nim').val() || '').trim() );
  });

  // Tombol detail (delegation)
  $(document).on('click', '.detail-btn', function() {
    const nim = $(this).data('nim');
    if (!globalToken) { Swal.fire('Error','Token tidak tersedia','error'); return; }
    getDetailMahasiswaLulusDO(nim);
  });

  // Cek query ?nim=...
  const urlNim = getUrlParameter('nim');
  if (urlNim) processNIM(urlNim);

  // Tombol cek PDDIKTI
  document.getElementById('cekPddiktiButton')?.addEventListener('click', function() {
    const nimInput = (document.getElementById('nim')?.value || '').trim();
    if (!nimInput) { Swal.fire('Perhatian','Harap masukkan NIM terlebih dahulu!','warning'); return; }
    window.open(`mahasiswa_pddikti.html?nim=${encodeURIComponent(nimInput)}`, '_blank');
  });
});
