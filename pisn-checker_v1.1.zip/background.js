let csrfToken = ""; // Variabel untuk menyimpan X-Csrf-Token

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "setCsrfToken") {
    csrfToken = request.csrfToken; // Set csrfToken
    console.log("X-Csrf-Token set:", csrfToken);
    return; // Tambahkan return untuk mencegah eksekusi lanjutan
  }

if (request.action === "makeApiRequest") {
    // Ambil token dari chrome.storage sebelum mengirim permintaan
    chrome.storage.local.get(['csrfToken'], (result) => {
      csrfToken = result.csrfToken || "default-token"; // Gunakan token yang diambil
      console.log("Sending request with X-Csrf-Token:", csrfToken);

      const url = "https://pisn.kemdikbud.go.id/operator/check-eligibility/search";
      const headers = {
        "X-Csrf-Token": csrfToken,
        "X-Requested-With": "XMLHttpRequest",
        "Content-Type": "application/x-www-form-urlencoded",
        "Sec-Fetch-Mode": "cors",
      };

      const body = new URLSearchParams({
        method: "input",
        institution_select: request.institution_select,
        study_level_select: request.study_level_select,
        study_program_select: request.study_program_select,
        student_id: request.student_id,
        proengsoft_jsvalidation: "",
        institution_study_program_id: request.institution_study_program_id,
        institution_code: request.institution_code
      });

      // Lakukan fetch request
      fetch(url, {
        method: "POST",
        headers: headers,
        body: body,
      })
        .then(response => {
          // Jika status code bukan 2xx atau 401, beri response error
          if (response.status === 401) {
            // Unauthorized, bisa karena token CSRF invalid atau hilang
            throw new Error("401 - Unauthenticated");
          } else if (!response.ok) {
            throw new Error("Network response was not ok: " + response.statusText);
          }

          // Jika status response ok, coba parse JSON
          return response.json();
        })
        .then(data => {
          console.log("Response data:", data);

          // Cek apakah API memberikan data atau pesan 'Unauthenticated'
          if (data.message === "Unauthenticated") {
            sendResponse({ message: "Unauthenticated", error: "Unauthorized - 401" });
          } else {
            sendResponse(data); // Kirim respons data ke content script
          }
        })
        .catch(error => {
          console.error("Error:", error);
          sendResponse({ error: error.message }); // Kirim error jika ada
        });

      return true; // Pastikan channel tetap terbuka hingga response dikirim
    });

    return true; // Penting! Agar message channel tetap terbuka
}


   if (request.action === 'getTokenNeofeeder') {
        // Lakukan fetch request untuk mengecek koneksi
        fetch(request.url, {
            method: request.method,
            headers: {
                'Content-Type': 'application/json',
                // Tambahkan header lain jika perlu
            },
            body: JSON.stringify(request.payload)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            sendResponse({ data });
        })
        .catch(error => {
            sendResponse({ error: error.message });
        });

        // Kembalikan true untuk menjaga koneksi terbuka
        return true;
    }

     if (request.action === 'apiNeofeeder') {
        // Lakukan fetch request untuk mengecek koneksi
        fetch(request.url, {
            method: request.method,
            headers: {
                'Content-Type': 'application/json',
                // Tambahkan header lain jika perlu
            },
            body: JSON.stringify(request.payload)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            sendResponse({ data });
        })
        .catch(error => {
            sendResponse({ error: error.message });
        });

        // Kembalikan true untuk menjaga koneksi terbuka
        return true;
    }




});

// Membuka halaman opsi ketika ikon extension diklik
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL("tentang.html") });
});
