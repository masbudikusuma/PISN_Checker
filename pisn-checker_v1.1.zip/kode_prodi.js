// Mapping kode jenjang ke nama jenjang
const kodeJenjangMapping = {
    "31": "Profesi",
    "32": "Spesialis",
    "37": "Sub Spesialis",
    "20": "Diploma I",
    "21": "Diploma II",
    "22": "Diploma III",
    "23": "Sarjana Terapan",
    "30": "Sarjana",
    "35": "Magister",
    "36": "Magister Terapan",
    "40": "Doktor",
    "41": "Doktor Terapan"
};

// Fungsi untuk mendapatkan kode jenjang dari nama jenjang
function getKodeJenjang(namaJenjang) {
    for (const [kode, jenjang] of Object.entries(kodeJenjangMapping)) {
        if (jenjang === namaJenjang) {
            return kode; // Kembalikan kode jika ada kecocokan
        }
    }
    return '-'; // Kode tidak ditemukan
}

// Event listener untuk tombol ambil data
fetchDataButton.addEventListener('click', async () => {
    const kodePT = document.getElementById('kode_pt').value;
    if (!kodePT) {
        alert('Harap masukkan Kode PT.');
        return;
    }

    notification.style.display = 'block';
    dataTableBody.innerHTML = '';

    try {
        const response = await fetch(
            `https://pisn.kemdikbud.go.id/institutions-pddikti-session/09795282-74DD-492B-8023-F5DE9577EE67/study-program?q=%&filterActiveStudyProgram=1&jenjang_didik_id=`,
            {
                method: 'GET',
                headers: {
                    'X-Csrf-Token': 'rZFiLWlm29fRxA9V6DadP99ZY6WZFr9INfpGeIst',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
        );

        if (!response.ok) throw new Error('Gagal mengambil data dari API');

        const data = await response.json();
        const programs = data.result;

        if (!Array.isArray(programs)) {
            throw new Error('Data result bukan array.');
        }

        programs.forEach((prodi, index) => {
            const kodeJenjang = getKodeJenjang(prodi.jenjang); // Ambil kode jenjang berdasarkan nama

            const row = `<tr>
                <td>${prodi.id}</td>
                <td>${prodi.nama}</td>
                <td>${prodi.kode}</td>
                <td>${prodi.jenjang}</td>
                <td>${kodeJenjang}</td>
            </tr>`;
            dataTableBody.innerHTML += row;

            const progressPercentage = ((index + 1) / programs.length) * 100;
            progress.style.width = progressPercentage + '%';
            progress.textContent = progressPercentage.toFixed(0) + '%';
        });

        progressContainer.style.display = 'block';
        notification.style.display = 'none';
        downloadButton.style.display = 'block';
    } catch (error) {
        alert('Error: ' + error.message);
        notification.style.display = 'none';
    }
});
