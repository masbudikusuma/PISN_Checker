let csrfToken = ""; // Variabel untuk menyimpan X-Csrf-Token
let namaPt = ""; // Variabel untuk menyimpan nama PT
let kodePddikti = ""; // Variabel untuk menyimpan kode PDDIKTI

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "setCsrfToken") {
    csrfToken = request.csrfToken; // Set csrfToken
    console.log("X-Csrf-Token set:", csrfToken);

    // Simpan token di chrome.storage untuk persisten
    chrome.storage.local.set({ csrfToken });
    return; // Mencegah eksekusi lanjutan
  }

  if (request.action === "fetchInstitutions") {
    fetch("https://pisn.kemdikbud.go.id/operator", {
      method: "GET",
      credentials: "include", // Sertakan cookie untuk autentikasi
    })
      .then(response => response.text())
      .then(html => {
        // Ekstrak objek institutions dari HTML menggunakan regex
        const regex = /const institutions = (.*?);/;
        const match = html.match(regex);

        if (match && match[1]) {
          const institutions = JSON.parse(match[1]); // Parsing objek JSON
          const id_pt = Object.keys(institutions)[0]; // Ambil key (ID PT)
          const institutionData = institutions[id_pt]; // Ambil data institusi berdasarkan ID

          // Ambil nama dan kode PDDIKTI dari data institusi
          // namaPt = institutionData.name; // "name": "Institut Agama Islam Negeri Metro"
          // kodePddikti = institutionData.pddikti_code; // "pddikti_code": "202033"

          // chrome.storage.local.set({ namaPt, kodePddikti }); // Simpan nama PT dan kode PDDIKTI
          chrome.storage.local.set({
        namaPt: institutionData.name,
        kodePddikti: institutionData.pddikti_code
    });


          console.log("Institusi diambil:", namaPt, kodePddikti); // Debug informasi

          sendResponse({ success: true, id_pt, data: institutionData });
        } else {
          sendResponse({ success: false, message: "Data institutions tidak ditemukan" });
        }
      })
      .catch(error => {
        console.error("Error fetching institutions:", error);
        sendResponse({ success: false, message: error.message });
      });

    return true; // Channel tetap terbuka hingga respons dikirim
  }

  if (request.action === "makeApiRequest") {
    // Ambil token dari chrome.storage sebelum request
    chrome.storage.local.get(['csrfToken'], (result) => {
      csrfToken = result.csrfToken || "default-token"; // Gunakan token yang ada
      console.log("Sending request with X-Csrf-Token:", csrfToken);

      const url = "https://pisn.kemdikbud.go.id/operator/check-eligibility/search";
      const headers = {
        "X-Csrf-Token": csrfToken,
        "X-Requested-With": "XMLHttpRequest",
        "Content-Type": "application/x-www-form-urlencoded",
        "Sec-Fetch-Mode": "cors",
      };

      const body = new URLSearchParams({
        method: "input",
        institution_select: request.institution_select,
        study_level_select: request.study_level_select, // Kode jenjang
        study_program_select: request.study_program_select,
        student_id: request.student_id,
        proengsoft_jsvalidation: "",
        institution_study_program_id: request.institution_study_program_id,
        institution_code: request.institution_code,
        nama_pt: namaPt, // Menambahkan nama PT yang diambil dari fetch
        kode_pddikti: kodePddikti // Menambahkan kode PDDIKTI yang diambil dari fetch
      });

      fetch(url, {
        method: "POST",
        headers: headers,
        body: body,
      })
        .then(response => {
          if (!response.ok) {
            throw new Error("Network response was not ok: " + response.statusText);
          }
          return response.json();
        })
        .then(data => {
          console.log("Response data:", data);
          sendResponse(data); // Kirim respons ke content script
        })
        .catch(error => {
          console.error("Error:", error);
          sendResponse({ error: error.message }); // Kirim error jika ada
        });

      return true; // Pastikan channel tetap terbuka hingga respons selesai
    });

    return true; // Penting untuk menjaga channel tetap terbuka
  }
});

// Membuka halaman opsi ketika ikon extension diklik
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
});
