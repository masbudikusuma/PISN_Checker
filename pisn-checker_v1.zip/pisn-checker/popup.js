document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("requestButton").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "makeApiRequest" }, (response) => {
      console.log("Received response:", response); // Log respons yang diterima
      const responseElement = document.getElementById("response");
      
      if (response.error) {
        responseElement.textContent = "Error: " + response.error; // Tampilkan error
      } else {
        responseElement.textContent = JSON.stringify(response, null, 2); // Tampilkan respons dalam format JSON
      }
    });
  });
});
