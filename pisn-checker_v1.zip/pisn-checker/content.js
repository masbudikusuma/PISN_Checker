// content.js

function getCsrfToken() {
  const csrfToken = document.querySelector('meta[name="csrf-token"]'); // Sesuaikan selector jika diperlukan
  return csrfToken ? csrfToken.getAttribute("content") : null;
}

const token = getCsrfToken();
if (token) {
  chrome.storage.local.set({ csrfToken: token }, () => {
    console.log("CSRF Token stored:", token);
  });
  chrome.runtime.sendMessage({ action: "setCsrfToken", csrfToken: token });
}
