document.addEventListener("DOMContentLoaded", function () {
    console.log("DOM content fully loaded and parsed.");

    // Ambil elemen-elemen yang diperlukan
    const apiForm = document.getElementById('apiForm');
    const downloadButton = document.getElementById('downloadButton');
    const progress = document.getElementById('progress');
    const responseError = document.getElementById('responseError');
    const responseBody = document.getElementById('responseBody');
    const progressContainer = document.getElementById('progressContainer');

    // Sembunyikan tombol download saat halaman pertama kali dimuat
    downloadButton.style.display = 'none';
    progressContainer.style.display = 'none';

    // Fungsi untuk menambahkan data mahasiswa ke tabel
    function addStudentDataToTable(studentId, data) {
        const student = data.students_data;

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${studentId}</td>
            <td>${data.message || 'N/A'}</td>
            <td>${student.eligible ? 'Yes' : 'No'}</td>
            <td>${student.eligible_status || 'N/A'}</td>
            <td>${student.certificate_number || 'N/A'}</td>
            <td>${student.batch_number || 'N/A'}</td>
            <td>${student.eligible_status_description || 'N/A'}</td>
            <td>${student.id_reg_pd || 'N/A'}</td>
            <td>${student.nipd || 'N/A'}</td>
             <td>
                  ${
                    student.nik?.eligible === "1"
                      ? `<button class="btn btn-success btn-sm" title="${student.nik?.hint || ''}">
                           ${student.nik?.value || 'N/A'} ${student.nik?.unit || ''}
                         </button>`
                      : `<button class="btn btn-danger btn-sm" title="${student.nik?.hint || ''}">
                           ${student.nik?.value || 'N/A'} ${student.nik?.unit || ''}
                         </button>`
                  }
            </td>
            <td>${student.tgl_keluar || 'N/A'}</td>
            <td>${student.tgl_sk_yudisium || 'N/A'}</td>
            <td>${student.no_seri_ijazah || 'N/A'}</td>
            <td>${student.id_jns_keluar || 'N/A'}</td>
            <td>${student.akreditasi_program_studi?.value || 'N/A'}</td>
            <td>${student.nama_mahasiswa?.value || 'N/A'}</td>
            <td>${student.masa_belajar?.value || 'N/A'} ${student.masa_belajar?.unit || ''}</td>
            <td>
                  ${
                    student.jumlah_sks?.eligible === "1"
                      ? `<button class="btn btn-success btn-sm" title="${student.jumlah_sks?.hint || ''}">
                           ${student.jumlah_sks?.value || 'N/A'} ${student.jumlah_sks?.unit || ''}
                         </button>`
                      : `<button class="btn btn-danger btn-sm" title="${student.jumlah_sks?.hint || ''}">
                           ${student.jumlah_sks?.value || 'N/A'} ${student.jumlah_sks?.unit || ''}
                         </button>`
                  }
            </td>
            <td>
                  ${
                    student.ipk?.eligible === "1"
                      ? `<button class="btn btn-success btn-sm" title="${student.ipk?.hint || ''}">
                           ${student.ipk?.value || 'N/A'} ${student.ipk?.unit || ''}
                         </button>`
                      : `<button class="btn btn-danger btn-sm" title="${student.ipk?.hint || ''}">
                           ${student.ipk?.value || 'N/A'} ${student.ipk?.unit || ''}
                         </button>`
                  }
            </td>
            <td>${student.sks_semester_antara?.value || 'N/A'} ${student.sks_semester_antara?.unit || ''}</td>
            <td>${student.pencatatan_pddikti?.value || 'N/A'} ${student.pencatatan_pddikti?.unit || ''}</td>
            <td>${student.is_accredited ? 'Yes' : 'No'}</td>
            
        `;
        responseBody.appendChild(row);
    }

    // Event listener untuk form submit
    apiForm.addEventListener('submit', function (event) {
        event.preventDefault();
        responseBody.innerHTML = ''; // Hapus data tabel sebelumnya
        responseError.textContent = ''; // Bersihkan error sebelumnya

        const institutionCode = document.getElementById('institutionCode').value.trim();
        const nimProdiInput = document.getElementById('nimProdi').value.trim();
        const records = nimProdiInput.split('\n').map(line => line.split(',').map(item => item.trim()));
        let completedRequests = 0;

        progressContainer.style.display = 'block'; // Tampilkan progress bar
        progress.style.width = '0%';
        progress.textContent = '0%';

        records.forEach(([studentId, studyProgramSelect, studyLevelSelect]) => {
            chrome.runtime.sendMessage({
                action: "makeApiRequest",
                student_id: studentId,
                institution_select: institutionCode,
                institution_code: institutionCode,
                study_program_select: studyProgramSelect,
                institution_study_program_id: studyProgramSelect,
                study_level_select: studyLevelSelect
            }, function (response) {
                completedRequests++;
                const percentage = Math.round((completedRequests / records.length) * 100);
                progress.style.width = `${percentage}%`;
                progress.textContent = `${percentage}%`;

                if (!response) {
                    responseError.textContent += `No response received for NIM ${studentId}.\n`;
                    return;
                }

                if (response.error) {
                    responseError.textContent += `Error for NIM ${studentId}: ${response.error}\n`;
                } else {
                    addStudentDataToTable(studentId, response);
                }

                // Tampilkan tombol download setelah semua request selesai
                if (completedRequests === records.length) {
                    downloadButton.style.display = 'block';
                }
            });
        });
    });

    // Fungsi untuk mengunduh data sebagai Excel
    downloadButton.addEventListener('click', function () {
        const workbook = XLSX.utils.book_new();
        const worksheet = XLSX.utils.table_to_sheet(document.getElementById('responseTable'));
        XLSX.utils.book_append_sheet(workbook, worksheet, "Response Data");

        XLSX.writeFile(workbook, "response_data.xlsx");
    });
});
