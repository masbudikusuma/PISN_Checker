// Mapping kode jenjang ke nama jenjang
const kodeJenjangMapping = {
    "31": "Profesi",
    "32": "Spesialis",
    "37": "Sub Spesialis",
    "20": "Diploma I",
    "21": "Diploma II",
    "22": "Diploma III",
    "23": "Sarjana Terapan",
    "30": "Sarjana",
    "35": "Magister",
    "36": "Magister Terapan",
    "40": "Doktor",
    "41": "Doktor Terapan"
};

// Fungsi untuk mendapatkan kode jenjang dari nama jenjang
function getKodeJenjang(namaJenjang) {
    for (const [kode, jenjang] of Object.entries(kodeJenjangMapping)) {
        if (jenjang === namaJenjang) {
            return kode;
        }
    }
    return '-';
}

// Fungsi untuk mengambil institutions dari halaman operator
async function fetchInstitutions() {
    try {
        const response = await fetch("https://pisn.kemdikbud.go.id/operator", {
            method: "GET",
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            }
        });

        if (!response.ok) {
            throw new Error("Gagal mengambil institutions.");
        }

        const text = await response.text();

        // Ekstrak objek institutions dari teks respons
        const match = text.match(/const institutions = (.+?);/);
        if (!match) {
            throw new Error("Institutions tidak ditemukan.");
        }

        const institutions = JSON.parse(match[1]);
        const institutionKeys = Object.keys(institutions);

        // Asumsikan ambil ID dari institutions pertama yang ditemukan
        const idPt = institutionKeys.length > 0 ? institutionKeys[0] : null;
        if (!idPt) {
            throw new Error("ID PT tidak ditemukan.");
        }

        console.log("ID PT ditemukan:", idPt);
        return idPt;
    } catch (error) {
        console.error("Error:", error);
        alert("Error: " + error.message);
    }
}

// Event listener untuk tombol ambil data
fetchDataButton.addEventListener('click', async () => {
    const idPt = await fetchInstitutions(); // Ambil ID PT secara dinamis
    if (!idPt) {
        alert("Gagal mengambil ID PT.");
        return;
    }

    notification.style.display = 'block';
    dataTableBody.innerHTML = '';

    try {
        const response = await fetch(
            `https://pisn.kemdikbud.go.id/institutions-pddikti-session/${idPt}/study-program?q=%&filterActiveStudyProgram=1&jenjang_didik_id=`,
            {
                method: 'GET',
                headers: {
                    'X-Csrf-Token': 'rZFiLWlm29fRxA9V6DadP99ZY6WZFr9INfpGeIst',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
        );

        if (!response.ok) throw new Error('Gagal mengambil data dari API.');

        const data = await response.json();
        const programs = data.result;

        if (!Array.isArray(programs)) {
            throw new Error('Data result bukan array.');
        }

        programs.forEach((prodi, index) => {
            const kodeJenjang = getKodeJenjang(prodi.jenjang);

            const row = `<tr>
                <td>${prodi.kode}</td>
                <td>${prodi.nama}</td>
                <td>${prodi.jenjang}</td>
                <td>${prodi.id}</td>
                <td>${kodeJenjang}</td>
            </tr>`;
            dataTableBody.innerHTML += row;

            const progressPercentage = ((index + 1) / programs.length) * 100;
            progress.style.width = progressPercentage + '%';
            progress.textContent = progressPercentage.toFixed(0) + '%';
        });

        progressContainer.style.display = 'block';
        notification.style.display = 'none';
        downloadButton.style.display = 'block';
    } catch (error) {
        alert('Error: ' + error.message);
        notification.style.display = 'none';
    }
});
