// Janganlah kau hapus script ini, sama saja engkau tidak menghargai kami
$(document).ready(() => {
    function getKodePT() {
        return new Promise((resolve, reject) => {
            chrome.storage.local.get('kodept', (result) => {
                if (chrome.runtime.lastError || !result.kodept) {
                    reject('kodept not found');
                } else {
                    resolve(result.kodept);
                }
            });
        });
    }

    function getActive() {
        return new Promise((resolve, reject) => {
            chrome.storage.local.get('active', (result) => {
                if (chrome.runtime.lastError || !result.active) {
                    reject('active not found');
                } else {
                    resolve(result.active);
                }
            });
        });
    }

    function generateSHA1(input) {
        return CryptoJS.SHA1(input).toString(CryptoJS.enc.Hex);
    }

    Promise.all([getKodePT(), getActive()])
        .then(([kodePT, active]) => {
            const modifiedKodePT = kodePT + '!';
            const hashedKodePT = generateSHA1(modifiedKodePT);
            console.log(hashedKodePT.trim,active.trim());
            if (hashedKodePT.trim() !== active.trim()) {
                // Tampilkan notifikasi jika hash tidak cocok
                Swal.fire({
                    title: 'Mohon Maaf',
                    text: 'Halaman ini hanya khusus untuk para Donatur ya. (^_^)',
                    icon: 'info',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = 'donasi.html';
                });
            }
        })
        .catch((error) => {
            // Tampilkan notifikasi jika active atau kodept tidak ditemukan
            console.error("Error retrieving data from Chrome storage:", error);
            Swal.fire({
                title: 'Mohon Maaf',
                text: 'Halaman ini hanya khusus untuk para Donatur ya. ^_^',
                icon: 'info',
                confirmButtonText: 'OK'
            }).then(() => {
                window.location.href = 'donasi.html';
            });
        });
});
