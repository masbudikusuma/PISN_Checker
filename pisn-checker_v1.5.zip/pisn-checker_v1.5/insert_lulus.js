document.addEventListener("DOMContentLoaded", function() {
    const inputForm = document.getElementById("inputForm");
    const generatedTableContainer = document.getElementById("generatedTableContainer");
    const generatedTableBody = document.getElementById("generatedTable").querySelector("tbody");
    const progressBar = document.getElementById("progressBar");

    // Fungsi untuk memperbarui progress bar
    function updateProgressBar(percentage) {
        progressBar.style.width = percentage + '%';
        progressBar.setAttribute('aria-valuenow', percentage);
        progressBar.innerText = percentage + '%';
    }

    // Event listener untuk form input
    inputForm.addEventListener("submit", function(event) {
        event.preventDefault(); // Mencegah form dari pengiriman default

        const inputData = document.getElementById("inputData").value.trim();
        const rows = inputData.split(/\n/); // Memisahkan input berdasarkan baris

        // Kosongkan tabel sebelum menambahkan data baru
        generatedTableBody.innerHTML = "";

        // Update progress bar
        updateProgressBar(0);

        rows.forEach((row, index) => {


            if (!row.trim()) return; // Lewati baris kosong atau hanya spasi/tab
            console.log(`Baris ${index + 1}:`, JSON.stringify(row));



            // Memisahkan kolom berdasarkan koma atau tab
            // const columns = row.split(/[\s,]+/); // Memisahkan berdasarkan spasi atau koma
            const columns = row.split('\t');
            while (columns.length < 8) {
                columns.push('');
            }
                        console.log('jumlah kolom:', columns.length);
            if (columns.length === 8) { // Pastikan ada 8 kolom
                const newRow = document.createElement("tr");

                // NIM
                const nimCell = document.createElement("td");
                nimCell.innerHTML = `<input type="text" value="${columns[0]}" class="form-control" />`;
                newRow.appendChild(nimCell);

                // Jenis Keluar (Dropdown)
                const jenisKeluarCell = document.createElement("td");
                jenisKeluarCell.innerHTML = `
                    <select class="form-control">
                        <option value="1" ${columns[1].toLowerCase() === 'lulus' ? 'selected' : ''}>Lulus</option>
                        <option value="2" ${columns[1].toLowerCase() === 'mutasi' ? 'selected' : ''}>Mutasi</option>
                        <option value="3" ${columns[1].toLowerCase() === 'dikeluarkan' ? 'selected' : ''}>Dikeluarkan</option>
                    <option value="4" ${columns[1].toLowerCase() === 'mengundurkan diri' ? 'selected' : ''}>Mengundurkan Diri</option>
                    </select>`;
                newRow.appendChild(jenisKeluarCell);

                // Tanggal Keluar
                const tanggalKeluarCell = document.createElement("td");
                const tanggalKeluar = columns[2];
                if (!isValidDate(tanggalKeluar)) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Salah',
                        text: 'Tanggal Keluar harus dalam format yyyy-mm-dd.',
                    });
                    return; // Hentikan proses jika tanggal tidak valid
                }
                tanggalKeluarCell.innerHTML = `<input type="date" value="${tanggalKeluar}" class="form-control" />`;
                newRow.appendChild(tanggalKeluarCell);

                // Periode Keluar
                const periodeKeluarCell = document.createElement("td");
                const periodeKeluar = columns[3];
                if (!/^\d{5}$/.test(periodeKeluar)) { // Validasi 5 digit angka
                    Swal.fire({
                        icon: 'error',
                        title: 'Salah',
                        text: 'Periode Keluar harus 5 digit angka.',
                    });
                    return; // Hentikan proses jika periode keluar tidak valid
                }
                periodeKeluarCell.innerHTML = `<input type="text" value="${periodeKeluar}" class="form-control" maxlength="5" />`;
                newRow.appendChild(periodeKeluarCell);

                // Tanggal SK
                const tanggalSkCell = document.createElement("td");
                const tanggalSk = columns[4];
                if (!isValidDate(tanggalSk)) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Salah',
                        text: 'Tanggal SK harus dalam format yyyy-mm-dd.',
                    });
                    return; // Hentikan proses jika tanggal tidak valid
                }
                tanggalSkCell.innerHTML = `<input type="date" value="${tanggalSk}" class="form-control" />`;
                newRow.appendChild(tanggalSkCell);

                // Nomor SK
                const nomorSkCell = document.createElement("td");
                nomorSkCell.innerHTML = `<input type="text" value="${columns[5]}" class="form-control" />`;
                newRow.appendChild(nomorSkCell);

                // IPK
                const ipkCell = document.createElement("td");
                const ipkValue = columns[6].replace(',', '.'); // Ganti koma dengan titik
                ipkCell.innerHTML = `<input type="text" value="${ipkValue}" class="form-control" />`;
                newRow.appendChild(ipkCell);

                // No Ijazah
                const noIjazahCell = document.createElement("td");
                noIjazahCell.innerHTML = `<input type="text" value="${columns[7]}" class="form-control" />`;
                newRow.appendChild(noIjazahCell);

                // Tambahkan kolom ID Reg PD dan Respon
                const idRegCell = document.createElement("td");
                idRegCell.innerHTML = `<input type="text" class="form-control" readonly />`; // ID Reg PD
                newRow.appendChild(idRegCell);

                const responseCell = document.createElement("td");
                responseCell.innerHTML = `<input type="text" class="form-control" readonly />`; // Respon
                newRow.appendChild(responseCell);

                generatedTableBody.appendChild(newRow);
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Salah',
                    text: 'Format input tidak valid. Pastikan ada 8 kolom.',
                });
            }

            // Update progress bar after each row
            const progressPercentage = Math.round(((index + 1) / rows.length) * 100);
            updateProgressBar(progressPercentage);
        });

        generatedTableContainer.style.display = "block"; // Tampilkan tabel
        updateProgressBar(100); // Set progress bar to 100% after processing
    });

    function isValidDate(dateString) {
        const regex = /^\d{4}-\d{2}-\d{2}$/; // Format yyyy-mm-dd
        return regex.test(dateString);
    }

    // Event listener untuk tombol Generate ID Reg
    document.getElementById("generateIdRegButton").addEventListener("click", function() {
        const rows = generatedTableBody.querySelectorAll("tr");
        const totalRows = rows.length;

        rows.forEach((row, index) => {
            const nimInput = row.querySelector("td input[type='text']").value; // Ambil NIM dari input
            const idRegCell = row.querySelector("td:nth-child(9)"); // Ambil sel ID Reg PD (kolom ke-9)
            generateIdReg(nimInput, idRegCell);

            // Update progress bar after each ID generation
            const progressPercentage = Math.round(((index + 1) / totalRows) * 100);
            updateProgressBar(progressPercentage);
        });
    });

    function generateIdReg(nim, idRegCell) {
        // Ambil data dari chrome.local.storage
        chrome.storage.local.get(['url', 'username', 'password'], function(items) {
            const url = items.url; // Ambil URL dari local storage
            const username = items.username; // Ambil kode prodi dari local storage
            const password = items.password; // Ambil password dari local storage

            // Request untuk mendapatkan token
            $.ajax({
                url: url, // Gunakan URL dari local storage
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({
                    act: "GetToken",
                    username: username,
                    password: password
                }),
                success: function(response) {
                    if (response.error_code === 0) {
                        const token = response.data.token;
                        // Simpan token ke chrome.local.storage
                        chrome.storage.local.set({ token: token }, function() {
                            console.log('Token disimpan:', token);
                        });

                        // Request untuk mendapatkan ID Reg
                        $.ajax({
                            url: url, // Gunakan URL dari local storage
                            method: 'POST',
                            contentType: 'application/json',
                            data: JSON.stringify({
                                act: 'GetDataLengkapMahasiswaProdi',
                                token: token,
                                filter: `nim='${nim}'`
                            }),
                            success: function(response) {
                                const data = response.data[0];
                                if (data && data.id_registrasi_mahasiswa) {
                                    idRegCell.querySelector('input').value = data.id_registrasi_mahasiswa; // Mengisi ID Reg PD
                                } else {
                                    idRegCell.querySelector('input').value = 'ID tidak ditemukan'; // Jika ID tidak ditemukan
                                }
                            },
                            error: function() {
                                idRegCell.querySelector('input').value = 'Error fetching ID'; // Jika terjadi error
                            }
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Salah',
                            text: 'Gagal mendapatkan token.',
                        });
                    }
                },
                error: function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Salah',
                        text: 'Gagal melakukan request untuk mendapatkan token.',
                    });
                }
            });
        });
    }

    // Fungsi untuk mengirim data ke API InsertMahasiswaLulusDO
    function insertMahasiswaLulusDO(record, responseCell) {
        chrome.storage.local.get(['url'], function(items) {
            const url = items.url; // Ambil URL dari local storage

            // Ambil token dari local storage
            chrome.storage.local.get(['token'], function(tokenItems) {
                const token = tokenItems.token; // Ambil token dari local storage

                $.ajax({
                    url: url, // Gunakan URL dari local storage
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        act: "InsertMahasiswaLulusDO",
                        token: token, // Sertakan token di sini
                        record: record // Sertakan record di sini
                    }),
                    success: function(response) {
                        if (response.error_code === 0) {
                            responseCell.querySelector('input').value = 'SUKSES'; // Tampilkan sukses di kolom respon
                        } else {
                            responseCell.querySelector('input').value = response.error_desc; // Tampilkan error_desc di kolom respon
                        }
                    },
                    error: function() {
                        responseCell.querySelector('input').value = 'Gagal melakukan request untuk menyimpan data.'; // Tampilkan error di kolom respon
                    }
                });
            });
        });
    }

    // Event listener untuk tombol Proses Insert
    document.getElementById("processButton").addEventListener("click", function() {
        const rows = generatedTableBody.querySelectorAll("tr");
        const records = [];

        rows.forEach(row => {
            const nim = row.querySelector("td input[type='text']").value;
            const jenisKeluar = row.querySelector("td:nth-child(2) select").value;
            const tanggalKeluar = row.querySelector("td:nth-child(3) input[type='date']").value;
            const periodeKeluar = row.querySelector("td:nth-child(4) input[type='text']").value;
            const nomorSk = row.querySelector("td:nth-child(6) input[type='text']").value;
            const tanggalSk = row.querySelector("td:nth-child(5) input[type='date']").value;
            const ipk = row.querySelector("td:nth-child(7) input[type='text']").value;
            const nomorIjazah = row.querySelector("td:nth-child(8) input[type='text']").value;

            records.push({
                id_registrasi_mahasiswa: row.querySelector("td:nth-child(9) input").value,
                id_jenis_keluar: jenisKeluar,
                tanggal_keluar: tanggalKeluar,
                id_periode_keluar: periodeKeluar,
                nomor_sk_yudisium: nomorSk,
                tanggal_sk_yudisium: tanggalSk,
                ipk: ipk,
                nomor_ijazah: nomorIjazah
            });
        });

        // Notifikasi sebelum eksekusi
        Swal.fire({
            title: 'Konfirmasi',
            text: "Data yang diinputkan ke Neoeeder, dan disinkronkan dengan PDDIKTI. Jika ada perubahan, hanya bisa dilakukan di PDDIKTI-admin.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Lanjutkan',
            cancelButtonText: 'Batalkan'
        }).then((result) => {
            if (result.isConfirmed) {
                records.forEach((record, index) => {
                    const responseCell = rows[index].querySelector("td:nth-child(10)"); // Ambil sel respon
                    insertMahasiswaLulusDO(record, responseCell);
                });
            }
        });
    });

    // Fungsi untuk mengonversi serial date Excel ke format yyyy-mm-dd
    function excelDateToJSDate(serial) {
        const utcDays = serial; // Jumlah hari
        const utcValue = new Date(Date.UTC(1899, 11, 30)); // Tanggal awal Excel
        return new Date(utcValue.setUTCDate(utcDays)); // Tambahkan jumlah hari
    }

    // Event listener untuk tombol Import By Excel
    document.getElementById("importExcel").addEventListener("click", function() {
        const fileInput = document.createElement("input");
        fileInput.type = "file";
        fileInput.accept = ".xlsx, .xls";
        fileInput.onchange = e => {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onload = e => {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const firstSheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[firstSheetName];
                const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

                // Kosongkan tabel sebelum menambahkan data baru
                generatedTableBody.innerHTML = "";

                // Mulai dari row 2
                for (let i = 1; i < jsonData.length; i++) {
                    const columns = jsonData[i];
                    if (columns.length === 8) { // Pastikan ada 8 kolom
                        const newRow = document.createElement("tr");

                        // NIM
                        const nimCell = document.createElement("td");
                        nimCell.innerHTML = `<input type="text" value="${columns[0]}" class="form-control" />`;
                        newRow.appendChild(nimCell);

                        // Jenis Keluar (Dropdown)
                        const jenisKeluarCell = document.createElement("td");
                        jenisKeluarCell.innerHTML = `
                            <select class="form-control">
                                <option value="1" ${columns[1].toLowerCase() === 'lulus' ? 'selected' : ''}>Lulus</option>
                                <option value="2" ${columns[1].toLowerCase() === 'mutasi' ? 'selected' : ''}>Mutasi</option>
                                <option value="3" ${columns[1].toLowerCase() === 'dikeluarkan' ? 'selected' : ''}>Dikeluarkan</option>
                            <option value="4" ${columns[1].toLowerCase() === 'mengundurkan diri' ? 'selected' : ''}>Mengundurkan Diri</option>
                            </select>`;
                        newRow.appendChild(jenisKeluarCell);

                        // Tanggal Keluar
                        const tanggalKeluarCell = document.createElement("td");
                        let tanggalKeluar = columns[2];
                        if (typeof tanggalKeluar === 'number') {
                            tanggalKeluar = excelDateToJSDate(tanggalKeluar).toISOString().split('T')[0]; // Konversi ke yyyy-mm-dd
                        }
                        if (!isValidDate(tanggalKeluar)) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Salah',
                                text: 'Tanggal Keluar harus dalam format yyyy-mm-dd.',
                            });
                            return; // Hentikan proses jika tanggal tidak valid
                        }
                        tanggalKeluarCell.innerHTML = `<input type="date" value="${tanggalKeluar}" class="form-control" />`;
                        newRow.appendChild(tanggalKeluarCell);

                        // Periode Keluar
                        const periodeKeluarCell = document.createElement("td");
                        const periodeKeluar = columns[3];
                        if (!/^\d{5}$/.test(periodeKeluar)) { // Validasi 5 digit angka
                            Swal.fire({
                                icon: 'error',
                                title: 'Salah',
                                text: 'Periode Keluar harus 5 digit angka.',
                            });
                            return; // Hentikan proses jika periode keluar tidak valid
                        }
                        periodeKeluarCell.innerHTML = `<input type="text" value="${periodeKeluar}" class="form-control" maxlength="5" />`;
                        newRow.appendChild(periodeKeluarCell);

                        // Tanggal SK
                        const tanggalSkCell = document.createElement("td");
                        let tanggalSk = columns[4];
                        if (typeof tanggalSk === 'number') {
                            tanggalSk = excelDateToJSDate(tanggalSk).toISOString().split('T')[0]; // Konversi ke yyyy-mm-dd
                        }
                        if (!isValidDate(tanggalSk)) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Salah',
                                text: 'Tanggal SK harus dalam format yyyy-mm-dd.',
                            });
                            return; // Hentikan proses jika tanggal tidak valid
                        }
                        tanggalSkCell.innerHTML = `<input type="date" value="${tanggalSk}" class="form-control" />`;
                        newRow.appendChild(tanggalSkCell);

                        // Nomor SK
                        const nomorSkCell = document.createElement("td");
                        nomorSkCell.innerHTML = `<input type="text" value="${columns[5]}" class="form-control" />`;
                        newRow.appendChild(nomorSkCell);

                        // IPK
                        const ipkCell = document.createElement("td");
                        let ipkValue = columns[6];
                        // Pastikan ipkValue adalah string
                        if (typeof ipkValue !== 'string') {
                            ipkValue = String(ipkValue); // Konversi ke string jika bukan
                        }
                        ipkValue = ipkValue.replace(',', '.'); // Ganti koma dengan titik
                        ipkCell.innerHTML = `<input type="text" value="${ipkValue}" class="form-control" />`;
                        newRow.appendChild(ipkCell);

                        // No Ijazah
                        const noIjazahCell = document.createElement("td");
                        noIjazahCell.innerHTML = `<input type="text" value="${columns[7]}" class="form-control" />`;
                        newRow.appendChild(noIjazahCell);

                        // Tambahkan kolom ID Reg PD dan Respon
                        const idRegCell = document.createElement("td");
                        idRegCell.innerHTML = `<input type="text" class="form-control" readonly />`; // ID Reg PD
                        newRow.appendChild(idRegCell);

                        const responseCell = document.createElement("td");
                        responseCell.innerHTML = `<input type="text" class="form-control" readonly />`; // Respon
                        newRow.appendChild(responseCell);

                        generatedTableBody.appendChild(newRow);
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Salah',
                            text: 'Format input tidak valid. Pastikan ada 8 kolom.',
                        });
                    }
                }

                generatedTableContainer.style.display = "block"; // Tampilkan tabel
            };
            reader.readAsArrayBuffer(file);
        };
        fileInput.click(); // Buka dialog file
    });

    // Event listener untuk tombol DownloadExcel
    document.getElementById("DownloadExcel").addEventListener("click", function() {
        const rows = generatedTableBody.querySelectorAll("tr");
        const data = [];

        // Header kolom
        const headers = [
            "NIM",
            "Tanggal Keluar",
            "Periode Keluar",
            "Tanggal SK",
            "Nomor SK",
            "IPK",
            "No Ijazah",
            "ID Reg PD",
            "Respon"
        ];
        data.push(headers); // Tambahkan header ke data

        // Ambil data dari tabel
        rows.forEach(row => {
            const rowData = [];
            row.querySelectorAll("td input").forEach(input => {
                rowData.push(input.value);
            });
            data.push(rowData);
        });

        // Buat worksheet dan workbook
        const worksheet = XLSX.utils.aoa_to_sheet(data);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Data");

        // Simpan file Excel
        XLSX.writeFile(workbook, "data_mahasiswa.xlsx");
    });
});
