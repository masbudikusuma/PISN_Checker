$(document).ready(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const nimParam = urlParams.get('nim');

    if (nimParam) {
        $('#nim').val(nimParam); // Set nilai NIM di input jika ada parameter
        $('#cekMahasiswaForm').submit(); // Otomatis submit form untuk cek mahasiswa
    }

    $('#cekMahasiswaForm').on('submit', function (e) {
        e.preventDefault(); // Mencegah form terkirim

        const nim = $('#nim').val();

        chrome.storage.local.get(['url', 'username', 'password'], (result) => {
            const url = result.url;
            const username = result.username;
            const password = result.password;

            if (!url || !username || !password) {
                alert('Konfigurasi NeoFeeder belum diatur. Harap isi URL, username, dan password.');
                return;
            }

            function getToken(callback) {
                $.ajax({
                    url: url,
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        act: 'GetToken',
                        username: username,
                        password: password
                    }),
                    success: (response) => {
                        if (response.error_code === 0) {
                            const token = response.data.token;
                            callback(token);
                        } else {
                            console.error('Error fetching token:', response.error_desc);
                            alert('Gagal mendapatkan token. Periksa kembali konfigurasi NeoFeeder.');
                        }
                    },
                    error: (xhr, status, error) => {
                        console.error('Error getting token:', error);
                        alert('Terjadi kesalahan saat mendapatkan token.');
                    }
                });
            }

            function getMahasiswa(token) {
                $.ajax({
                    url: url,
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        act: 'GetDataLengkapMahasiswaProdi',
                        token: token,
                        filter: `nim='${nim}'`
                    }),
                    success: (response) => {
                        if (response.error_code === 0) {
                            const data = response.data[0];
                            if (data) {
                                const nikColor = data.nik && data.nik.length === 16 ? 'green' : 'red';

                                const html = `
                                <h6>Data Profil Mahasiswa</h6>
                                <p><strong>ID Reg:</strong> ${data.id_registrasi_mahasiswa}</p>
                                <p><strong>ID Mahasiswa:</strong> ${data.id_mahasiswa}</p>
                                <p><strong>NIK:</strong> <span style="color: ${nikColor};">${data.nik || 'N/A'}</span></p>
                                <p><strong>Email:</strong> ${data.email || 'N/A'}</p>
                                <p><strong>Nama Mahasiswa:</strong> ${data.nama_mahasiswa || 'N/A'}</p>
                                <p><strong>Jenis Kelamin:</strong> ${data.jenis_kelamin || 'N/A'}</p>
                                <p><strong>Tanggal Lahir:</strong> ${data.tanggal_lahir || 'N/A'}</p>
                                <p><strong>Program Studi:</strong> ${data.nama_program_studi || 'N/A'}</p>
                                <p><strong>Status Mahasiswa:</strong> ${data.nama_status_mahasiswa || 'N/A'}</p>
                                `;

                                $('#result-profile').html(html);

                                // Update form NIK/Email
                                $('#nik').val(data.nik || ''); // Isi default value untuk NIK
                                $('#email').val(data.email || ''); // Isi default value untuk Email
                                $('#updateFormContainer').show();

                                // Tambahkan event listener untuk form update
                                $('#updateNIKForm').on('submit', function (e) {
                                    e.preventDefault(); // Mencegah form terkirim
                                    updateMahasiswa(token, data.id_mahasiswa);
                                });
                            } else {
                                alert('Data mahasiswa tidak ditemukan.');
                            }
                        } else {
                            console.error('Error fetching mahasiswa data:', response.error_desc);
                            alert('Gagal mengambil data mahasiswa.');
                        }
                    },
                    error: (xhr, status, error) => {
                        console.error('Error fetching mahasiswa data:', error);
                        alert('Terjadi kesalahan saat mengambil data mahasiswa.');
                    }
                });
            }

            function updateMahasiswa(token, id_mahasiswa) {
                const updatedNIK = $('#nik').val();
                const updatedEmail = $('#email').val();

                $.ajax({
                    url: url,
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        act: 'UpdateBiodataMahasiswa',
                        token: token,
                        key: { id_mahasiswa: id_mahasiswa },
                        record: {
                            nik: updatedNIK,
                            email: updatedEmail
                        }
                    }),
                    success: (response) => {
                        if (response.error_code === 0) {
                            Swal.fire({
                                title: 'Data Berhasil Diperbarui!',
                                text: 'Jangan lupa melakukan sinkronisasi pada Neofeeder agar data terupdate di PDDIKTI.',
                                icon: 'success',
                                confirmButtonText: 'Ok',
                                customClass: {
                                    confirmButton: 'btn btn-success'
                                }
                            }).then(() => {
                                // Redirect ke halaman dengan NIM di URL
                                window.location.href = `update_nik.html?nim=${nim}`;
                            });
                        } else {
                            alert(`Gagal update data: ${response.error_desc}`);
                        }
                    },
                    error: (xhr, status, error) => {
                        console.error('Error updating mahasiswa data:', error);
                        alert('Terjadi kesalahan saat memperbarui data mahasiswa.');
                    }
                });
            }

            getToken((newToken) => {
                getMahasiswa(newToken);
            });
        });
    });
});
