let csrfToken = ""; // Variabel untuk menyimpan X-Csrf-Token

chrome.runtime.onInstalled.addListener(() => {
    // Membuka tab baru dengan URL yang mengarah ke 'tentang.html'
    chrome.tabs.create({ url: chrome.runtime.getURL('tentang.html') });
});


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "setCsrfToken") {
    csrfToken = request.csrfToken; // Set csrfToken
    console.log("X-Csrf-Token set:", csrfToken);
    return; // Tambahkan return untuk mencegah eksekusi lanjutan
  }

  if (request.action === "makeApiRequest") {
    chrome.storage.local.get(['csrfToken'], (result) => {
      csrfToken = result.csrfToken || "default-token"; // Gunakan token yang diambil
      console.log("Sending request with X-Csrf-Token:", csrfToken);

      const url = "https://pisn.kemdiktisaintek.go.id/operator/check-eligibility/search";
      const headers = {
        "X-Csrf-Token": csrfToken,
        "X-Requested-With": "XMLHttpRequest",
        "Content-Type": "application/x-www-form-urlencoded",
        "Sec-Fetch-Mode": "cors",
      };

      const body = new URLSearchParams({
        method: "input",
        institution_select: request.institution_select,
        study_level_select: request.study_level_select,
        study_program_select: request.study_program_select,
        student_id: request.student_id,
        proengsoft_jsvalidation: "",
        institution_study_program_id: request.institution_study_program_id,
        institution_code: request.institution_code
      });

      // Lakukan fetch request
      fetch(url, {
        method: "POST",
        headers: headers,
        body: body,
      })
        .then(response => {
          if (response.status === 401) {
            throw new Error("401 - Unauthenticated");
          } else if (!response.ok) {
            throw new Error("Network response was not ok: " + response.statusText);
          }
          return response.json();
        })
        .then(data => {
          console.log("Response data:", data);
          if (data.message === "Unauthenticated") {
            sendResponse({ message: "Unauthenticated", error: "Unauthorized - 401" });
          } else {
            sendResponse(data);
          }
        })
        .catch(error => {
          console.error("Error:", error);
          sendResponse({ error: error.message });
        });

      return true; // Pastikan channel tetap terbuka hingga response dikirim
    });

    return true; // Penting! Agar message channel tetap terbuka
  }

  if (request.action === "getTokenNeofeeder") {
    fetch(request.url, {
      method: request.method,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(request.payload)
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      sendResponse({ data });
    })
    .catch(error => {
      sendResponse({ error: error.message });
    });

    return true;
  }

  if (request.action === "apiNeofeeder") {
    fetch(request.url, {
      method: request.method,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(request.payload)
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      sendResponse({ data });
    })
    .catch(error => {
      sendResponse({ error: error.message });
    });

    return true;
  }

});

// Membuka halaman opsi ketika ikon extension diklik
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL("tentang.html") });
});
