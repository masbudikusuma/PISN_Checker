let csrfToken; // Variabel global untuk menyimpan csrfToken        
let idPddikti; // Variabel untuk menyimpan ID PDDIKTI        
  
// Fungsi untuk mengambil csrfToken dari chrome.storage.local        
function getCsrfToken() {        
    chrome.storage.local.get(['csrfToken'], function(result) {        
        csrfToken = result.csrfToken; // Simpan csrfToken ke variabel global        
        $('#_token').val(csrfToken); // Isi nilai _token di form        
        getIdPddikti(); // Panggil fungsi untuk mendapatkan ID PDDIKTI    
    });        
}        
  
// Fungsi untuk mengambil Institution Code dari chrome.storage.local  
function getInstitutionCode() {  
    chrome.storage.local.get(['kodept'], function(result) {  
        const institutionCode = result.kodept || ''; // Ambil kodept dari local storage  
        $('#institution_code').val(institutionCode); // Isi nilai institution_code di form  
    });  
}  
  
// Fungsi untuk mengambil ID PDDIKTI dari chrome.storage    
function getIdPddikti() {    
    chrome.storage.local.get(['idpt'], function(result) {    
        idPddikti = result.idpt ? result.idpt.toUpperCase() : ''; // Mengubah ID menjadi huruf kapital  
        if (idPddikti) {    
            fetchStudyPrograms(idPddikti); // Panggil fungsi untuk mengambil program studi    
        } else {    
            console.error("ID PDDIKTI tidak ditemukan");    
        }    
    });    
}        
  
// Fungsi untuk mengambil data program studi dari API    
function fetchStudyPrograms(idPddikti) {    
    const url = `https://pisn.kemdiktisaintek.go.id/institutions-pddikti-session/${idPddikti}/study-program?q=%&filterActiveStudyProgram=1&jenjang_didik_id=`;    
  
    // Show loading animation  
    $('#loading').show();    
  
    $.ajax({    
        url: url,    
        type: "GET",    
        headers: {    
            'X-Csrf-Token': csrfToken,    
            'X-Requested-With': 'XMLHttpRequest',    
            'Content-Type': 'application/x-www-form-urlencoded'    
        },    
        success: function(response) {    
            if (response.status === 200) {    
                populateDropdown(response.result); // Panggil fungsi untuk mengisi dropdown    
            } else {    
                console.error("Error fetching study programs:", response.message);    
            }    
        },    
        error: function(jqXHR) {    
            console.error("Request failed:", jqXHR);    
        },    
        complete: function() {    
            // Hide loading animation after request completes  
            $('#loading').hide();    
        }    
    });    
}  
  
// Fungsi untuk mengisi dropdown dengan program studi    
function populateDropdown(programs) {    
    const dropdown = $('#institution_study_program_id');    
    dropdown.empty(); // Kosongkan dropdown    
    dropdown.append('<option value="">Pilih Program Studi</option>'); // Tambahkan opsi default    
    
    programs.forEach(program => {    
        dropdown.append(`<option value="${program.id}" data-kode="${program.kode}">${program.jenjang} - ${program.nama}</option>`);    
    });    
}       
  
$(document).ready(function() {      

        $('#search_institution_study_program').on('input', function() {  
        const searchTerm = $(this).val().toLowerCase(); // Get the input value and convert to lowercase  
        $('#institution_study_program_id option').each(function() {  
            const optionText = $(this).text().toLowerCase(); // Get the text of each option  
            if (optionText.includes(searchTerm) || searchTerm === '') {  
                $(this).show(); // Show option if it matches the search term  
            } else {  
                $(this).hide(); // Hide option if it doesn't match  
            }  
        });  
    });  
  
  
    getCsrfToken(); // Ambil csrfToken saat dokumen siap      
    getInstitutionCode(); // Ambil Institution Code dari local storage  
  
    // Event listener untuk mengonversi input menjadi huruf kapital      
    $('#institution_study_program_id').on('input', function() {      
        this.value = this.value.toUpperCase();      
    });      
  
    $('#id_reg_pd').on('input', function() {      
        this.value = this.value.toUpperCase();      
    });      
  
    // Event listener untuk memilih program studi dari dropdown      
    $('#institution_study_program_id').on('change', function() {      
        const selectedOption = $(this).find('option:selected');      
        const selectedId = selectedOption.val();      
        const selectedKode = selectedOption.data('kode');      
  
        if (selectedId) {      
            $('#study_program_code').val(selectedKode); // Isi kode ke input      
            $('#institution_study_program_id_input').val(selectedId); // Isi ID ke input      
        } else {      
            $('#study_program_code').val(''); // Kosongkan kode jika tidak ada yang dipilih      
            $('#institution_study_program_id_input').val(''); // Kosongkan ID jika tidak ada yang dipilih      
        }      
    });      
  
    $('#generateForm').on('submit', function(event) {      
        event.preventDefault(); // Mencegah form dari submit default      
  
        const formData = new FormData(this);      
        const _token = $('#_token').val();      
        const institution_code = $('#institution_code').val();      
        const study_program_code = $('#study_program_code').val();      
        const institution_study_program_id = $('#institution_study_program_id_input').val();      
        const proengsoft_jsvalidation = $('#proengsoft_jsvalidation').val();      
        const id_reg_pd = $('#id_reg_pd').val().split(',').map(id => id.trim());      
        const yudisium_letter = $('#yudisium_letter')[0].files[0];      
        const statement_letter = $('#statement_letter')[0].files[0];      
  
        // First Request: URL-encoded data with _jsvalidation=yudisium_letter      
        const firstRequestData = {      
            _token: _token,      
            institution_code: institution_code,      
            study_program_code: study_program_code,      
            institution_study_program_id: institution_study_program_id,      
            proengsoft_jsvalidation: proengsoft_jsvalidation,      
            id_reg_pd: id_reg_pd,      
            _jsvalidation: 'yudisium_letter',      
            _jsvalidation_validate_all: false      
        };      
  
        // Second Request: URL-encoded data with _jsvalidation=statement_letter      
        const secondRequestData = {      
            _token: _token,      
            institution_code: institution_code,      
            study_program_code: study_program_code,      
            institution_study_program_id: institution_study_program_id,      
            proengsoft_jsvalidation: proengsoft_jsvalidation,      
            id_reg_pd: id_reg_pd,      
            _jsvalidation: 'statement_letter',      
            _jsvalidation_validate_all: false      
        };      
  
        // Third Request: Multipart form data including file uploads      
        const thirdRequestData = new FormData();      
        thirdRequestData.append('_token', _token);      
        thirdRequestData.append('institution_code', institution_code);      
        thirdRequestData.append('study_program_code', study_program_code);      
        thirdRequestData.append('institution_study_program_id', institution_study_program_id);      
        thirdRequestData.append('proengsoft_jsvalidation', proengsoft_jsvalidation);      
        id_reg_pd.forEach(id => thirdRequestData.append('id_reg_pd[]', id));      
        thirdRequestData.append('yudisium_letter', yudisium_letter);      
        thirdRequestData.append('statement_letter', statement_letter);      
  
        // Function to handle AJAX requests      
        function makeRequest(url, data, contentType, processData, successCallback, errorCallback) {      
            $.ajax({      
                url: url,      
                type: "POST",      
                data: data,      
                contentType: contentType,      
                processData: processData,      
                beforeSend: function(xhr) {      
                    xhr.setRequestHeader("X-Csrf-Token", csrfToken);      
                    xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");      
                },      
                success: successCallback,      
                error: errorCallback      
            });      
        }      
  
        // First Request      
        makeRequest(      
            "https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/generate",      
            $.param(firstRequestData),      
            "application/x-www-form-urlencoded; charset=UTF-8",      
            true,      
            function(response) {      
                console.log("First request success:", response);      
                // Second Request      
                makeRequest(      
                    "https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/generate",      
                    $.param(secondRequestData),      
                    "application/x-www-form-urlencoded; charset=UTF-8",      
                    true,      
                    function(response) {      
                        console.log("Second request success:", response);      
                        // Third Request      
                        makeRequest(      
                            "https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/generate",      
                            thirdRequestData,      
                            false,      
                            false,      
                            function(response) {      
                                console.log("Third request success:", response);      
                                // Open new tab after third request    
                                window.open("https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/generate", "_blank");    
                            },      
                            function(jqXHR) {      
                                handleError(jqXHR);      
                            }      
                        );      
                    },      
                    function(jqXHR) {      
                        handleError(jqXHR);      
                    }      
                );      
            },      
            function(jqXHR) {      
                handleError(jqXHR);      
            }      
        );      
    });      
  
    function handleError(jqXHR) {      
        if (jqXHR.responseJSON && jqXHR.responseJSON.message === "Unauthenticated.") {      
            Swal.fire({      
                icon: 'warning',      
                title: 'Session Login PISN Tidak Ditemukan',      
                html: 'Silahkan Login terlebih dahulu di <a href="https://pisn.kemdikbud.go.id/login">pisn.kemdikbud.go.id/login</a>',      
                confirmButtonText: 'OK'      
            });      
        } else {      
            Swal.fire({      
                icon: 'error',      
                title: 'Kesalahan',      
                text: 'Terjadi kesalahan saat menghasilkan sertifikat. Silakan coba lagi.',      
                confirmButtonText: 'OK'      
            });      
        }      
    }      
});  
