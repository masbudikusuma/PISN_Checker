// Fungsi umum untuk mengirim request ke background script
async function sendRequestToBackground(url, method, payload, action) {
    console.log("mengirim background ",url, "&Action : ",action," dan Payload",payload);
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ url, method, payload, action }, (response) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else if (response && response.error) {
                reject(new Error(response.error));
            } else {
                resolve(response);
            }
        });
    });
}

// Fungsi untuk request profil PT
async function apiFeeder(url, payload) {
    try {
        // console.log("mencoba koneksi ke ",url, "dan Payload",payload);
        const response = await sendRequestToBackground(url, 'POST', payload, 'apiNeofeeder');
        
        if (response.data && Array.isArray(response.data.data) && response.data.data.length > 0) {
            return response.data.data[0];
        } else {
            throw new Error('Data profil PT tidak ditemukan.');
        }
    } catch (error) {
        console.error('Error:', error);
        throw new Error('Gagal mendapatkan profil PT.');
    }
}

// Fungsi untuk mendapatkan token
async function getToken(url, method, payload) {
    return await sendRequestToBackground(url, method, payload, 'getTokenNeofeeder');
}

// Event listener untuk pengiriman form
document.addEventListener('DOMContentLoaded', () => {
    loadConfiguration(); // Memuat konfigurasi saat halaman dimuat

    // Menangani event submit pada form
    document.getElementById('apiForm').addEventListener('submit', async (event) => {
        event.preventDefault(); // Mencegah form submit secara default
        
        const url = document.getElementById('url').value;
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        // Validasi input
    if (!url || !username || !password) {
        Swal.fire('Error', 'Semua kolom harus diisi', 'error');
        return;
    }
        const payload = {
            act: "GetToken",
            username: username,
            password: password
        };

        try {
            const response = await getToken(url, 'POST', payload);
            const responseOutput = document.getElementById('responseOutput');

            const { error_code, error_desc, data } = response.data;
if (error_code === 0) {
    

    const token = data.token;
    responseOutput.innerHTML = `
        <b>Token berhasil didapatkan:</b><br>
        Error Code: ${error_code}<br>
        Error Desc: ${error_desc}<br>
        Token: ${token}
    `;

    chrome.storage.local.set({ url, username, password }, () => {
        console.log('Data disimpan ke storage lokal.');
    });

    try {
        const payload_GetProfilPT = {
            act: "GetProfilPT",
            token: token,
            filter: "",
            order: "",
            limit: "",
            offset: ""
        };
        const profilPT = await apiFeeder(url, payload_GetProfilPT);
        
        const kodept = profilPT.kode_perguruan_tinggi;
        const namapt = profilPT.nama_perguruan_tinggi;
        const idpt = profilPT.id_perguruan_tinggi;

        chrome.storage.local.set({ kodept, namapt }, () => {
            console.log('Kode PT dan Nama PT berhasil disimpan.');
        });

Swal.fire({
    title: 'Profil Perguruan Tinggi',
    html: `
        <p><strong>ID PT: </strong>${profilPT.id_perguruan_tinggi}</p>
        <p><strong>Kode PT: </strong>${kodept}</p>
        <p><strong>Nama PT: </strong>${namapt}</p>
        <p><strong>Telepon: </strong>${profilPT.telepon}</p>
        <p><strong>Fax: </strong>${profilPT.faximile}</p>
        <p><strong>Email: </strong>${profilPT.email}</p>
        <p><strong>Website: </strong>${profilPT.website}</p>
        <button id="cek-koneksi-pddikti" style="margin-top: 10px;" class="swal2-confirm swal2-styled">
            Cek Koneksi PDDIKTI
        </button>
    `,
    showCancelButton: true,
    confirmButtonText: 'Simpan Konfigurasi',
    cancelButtonText: 'Kembali',
    didOpen: () => {
        // Tambahkan event listener ke tombol "Cek Koneksi PDDIKTI"
        document.getElementById('cek-koneksi-pddikti').addEventListener('click', () => {
            // Arahkan ke halaman pddikti.html
            window.location.href = 'pddikti.html';
        });
    }
}).then((result) => {
    if (result.isConfirmed) {
        chrome.storage.local.set(
            { url, username, password, kodept, namapt, idpt },
            () => {
                console.log('Konfigurasi lengkap berhasil disimpan.');
            }
        );

        // Arahkan ke dashboard setelah konfigurasi disimpan
        window.location.href = 'cekpin.html';
    }
});

    } catch (error) {
        console.error('Gagal mendapatkan profil PT:', error);
        responseOutput.innerHTML = `<b>Error:</b> ${error.message}`;
    }
} else {
    responseOutput.textContent = `Error: ${error_desc || 'Terjadi kesalahan saat mendapatkan token.'}`;
}

        } catch (error) {
            document.getElementById('responseOutput').textContent = error.message;
        }
    });

    // Menangani klik untuk tombol Clear Configuration
    document.getElementById('clearConfig').addEventListener('click', clearConfiguration);
});

// Fungsi untuk memuat konfigurasi dari storage
function loadConfiguration() {
    chrome.storage.local.get(['url', 'username', 'password'], (config) => {
        document.getElementById('url').value = config.url || '';
        document.getElementById('username').value = config.username || '';
        document.getElementById('password').value = config.password || '';

        document.getElementById('clearConfig').disabled = !(config.url || config.username || config.password);
    });
}

// Fungsi untuk menghapus konfigurasi dari storage
function clearConfiguration() {
    chrome.storage.local.clear(() => {
        console.log('Konfigurasi dihapus.');
        loadConfiguration(); // Muat ulang konfigurasi
    });
}
