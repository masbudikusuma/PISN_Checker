$(document).ready(function() {
  // Ambil data PISN dari chrome.storage.local
  chrome.storage.local.get(['datePddikti'], (result) => {
    // Cek apakah data PISN ada di local storage
    if (chrome.runtime.lastError || !result.datePddikti) {
      console.error("Error fetching PISN HTML atau data tidak ditemukan.");
      // Fallback: Tampilkan pesan default
      updatePisnContent("Cek Eligible PISN");
    } else {
      console.log("PISN Data:", result.datePddikti);
      // Update konten dengan data yang diambil
      updatePisnContent(result.datePddikti);
    }
  });

  // Fungsi untuk memperbarui konten di halaman
  function updatePisnContent(text) {
  const targetElement = document.querySelector(".updatepddikti");
  if (targetElement) {
    // Tambahkan teks di bawah elemen target dengan tag <strong> untuk membuatnya bold
    const newElement = document.createElement("p");
    const strongElement = document.createElement("strong");
    strongElement.textContent = text;
    newElement.appendChild(strongElement); // Menambahkan elemen strong ke dalam p
    newElement.className = "text-info mt-2"; // Tambahkan kelas styling jika diperlukan
    targetElement.appendChild(newElement);
  } else {
    console.error("Target element not found!");
  }
}
});
document.getElementById('generateProdiBtn').addEventListener('click', function() {
    const nimInputElement = document.getElementById('nimInput');
    if (!nimInputElement) {
        console.error('Element with id "nimInput" not found.');
        return;
    }

    const nimInput = nimInputElement.value.trim();
    const records = nimInput.split('\n').map(item => item.trim()).filter(item => item);

    if (records.length === 0) {
        alert('Silakan masukkan NIM terlebih dahulu!');
        return;
    }

    // Resetkan data tabel (jika diperlukan, untuk memulai pengolahan data dari awal)
    document.getElementById('responseBody').innerHTML = '';

    // Ambil url, username, password, dan kodept dari storage
    chrome.storage.local.get(['url', 'username', 'password', 'kodept'], (result) => {
        const url = result.url;
        const username = result.username;
        const password = result.password;
        const institutionCode = result.kodept; // Ambil kodept dari localStorage

        if (!institutionCode) {
            console.error('Institution code (kodept) not found in local storage.');
            alert('Kode PT tidak ditemukan dalam storage. Lakukan pengaturan pada menu Konfigurasi Neofeeder');
            return; // Menghentikan jika kodept tidak ditemukan
        }

        let token = null; // Deklarasi token di luar agar bisa digunakan di seluruh scope

        // Fungsi untuk mendapatkan token
        function getToken(callback) {
            $.ajax({
                url: url,
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({
                    act: 'GetToken',
                    username: username,
                    password: password
                }),
                success: (response) => {
                    token = response.data.token; // Set token
                    callback(token); // Panggil callback dengan token
                },
                error: (xhr, status, error) => {
                    console.error('Error getting token:', error);
                    alert('Terjadi kesalahan saat mendapatkan token.');
                }
            });
        }

        // Fungsi untuk mendapatkan data mahasiswa berdasarkan NIM
        function getMahasiswa(token, nim) {
            $.ajax({
                url: url,
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({
                    act: 'GetListMahasiswa',
                    token: token,
                    filter: `nim='${nim}'`
                }),
                success: (response) => {
                    const data = response.data[0];
                    const currentContent = document.getElementById('nimInput').value.trim(); // Ambil nilai textarea yang ada
                    let newContent = currentContent; // Default nilai baru akan tetap sama

                    if (data) {
                        // Tentukan kode berdasarkan nama_program_studi
                        let programCode = '';
                        if (data.nama_program_studi.includes('S1')) {
                            programCode = '30'; // S1
                        } else if (data.nama_program_studi.includes('S2')) {
                            programCode = '35'; // S2
                        } else if (data.nama_program_studi.includes('S3')) {
                            programCode = '40'; // S3
                        } else if (data.nama_program_studi.includes('D1')) {
                            programCode = '20'; // D1
                        } else if (data.nama_program_studi.includes('D2')) {
                            programCode = '21'; // D2
                        } else if (data.nama_program_studi.includes('D3')) {
                            programCode = '22'; // D3
                        } else if (data.nama_program_studi.includes('D4')) {
                            programCode = '23'; // D4
                        } else if (data.nama_program_studi.includes('Profesi')) {
                            programCode = '31'; // Profesi
                        } else if (data.nama_program_studi.includes('Sp-1')) {
                            programCode = '32'; // Sp-1
                        } else if (data.nama_program_studi.includes('S2 Terapan')) {
                            programCode = '36'; // S2 Terapan
                        } else if (data.nama_program_studi.includes('S3 Terapan')) {
                            programCode = '41'; // S3 Terapan
                        } else {
                            programCode = 'Unknown'; // Jika tidak ada yang cocok
                        }

                        // Format data sesuai dengan aturan
                        const formattedData = `${data.nipd},${data.id_sms},${programCode}`;
                        
                        // Mengganti baris dengan NIM yang sudah ada (hapus NIM lama jika ada)
                        const regex = new RegExp(`^${nim}.*`, 'm'); // Regex untuk mencari baris dengan NIM yang sama
                        newContent = currentContent.replace(regex, formattedData);
                    } else {
                        // Jika data tidak ditemukan, tambahkan "tidak ditemukan" setelah NIM
                        const notFoundMessage = `${nim}, tidak ditemukan`;
                        const regex = new RegExp(`^${nim}.*`, 'm'); // Regex untuk mencari NIM yang sama
                        newContent = currentContent.replace(regex, notFoundMessage);
                    }

                    // Update textarea dengan hasil baru
                    document.getElementById('nimInput').value = newContent;
                },
                error: (xhr, status, error) => {
                    console.error('Error fetching mahasiswa data:', error);
                    alert('Terjadi kesalahan saat mengambil data mahasiswa.');
                }
            });
        }

        // Pastikan token sudah ada sebelum memanggil getMahasiswa
        if (!token) {
            getToken((newToken) => {
                token = newToken; // Set token baru
                records.forEach(nim => getMahasiswa(token, nim)); // Panggil fungsi untuk setiap NIM
            });
        } else {
            records.forEach(nim => getMahasiswa(token, nim)); // Gunakan token yang ada
        }
    });
});

// Event listener untuk form submit
document.getElementById('apiForm').addEventListener('submit', function (event) {
    event.preventDefault();

    // Ambil data dari chrome.storage.local
    chrome.storage.local.get(['kodept'], (result) => {
        const institutionCode = result.kodept; // Ambil kodept dari localStorage

        if (!institutionCode) {
            console.error('Institution code (kodept) not found in local storage.');
            alert('Kode PT tidak ditemukan dalam storage.');
            return; // Menghentikan jika kodept tidak ditemukan
        }

        const nimProdiInputElement = document.getElementById('nimInput');
        if (!nimProdiInputElement) {
            console.error('Element with id "nimInput" not found.');
            return;
        }

        const nimProdiInput = nimProdiInputElement.value.trim();
        const progress = document.getElementById('progress-bar');
        const responseError = document.getElementById('responseError');
        const downloadButton = document.getElementById('downloadButton');

        responseError.textContent = '';
        downloadButton.style.display = 'none';
        progress.style.width = '0%';
        progress.textContent = '0%';

        const records = nimProdiInput.split('\n'); // Split berdasarkan baris baru
        let completedRequests = 0;

        records.forEach((record, index) => {
            const [studentId, studyProgramSelect, studyLevelSelect] = record.split(',').map(item => item.trim());

            chrome.runtime.sendMessage({
                action: "makeApiRequest",
                student_id: studentId,
                institution_select: institutionCode,
                institution_code: institutionCode,
                study_program_select: studyProgramSelect,
                institution_study_program_id: studyProgramSelect,
                study_level_select: studyLevelSelect // Tambahkan kode_jenjang
            }, function (response) {
                completedRequests++;
                progress.style.width = `${(completedRequests / records.length) * 100}%`;
                progress.textContent = `${Math.round((completedRequests / records.length) * 100)}%`;

                if (!response) {
                    responseError.textContent += `No response received for NIM ${studentId}.\n`;
                    return;
                }

                if (response.error) {
                    responseError.textContent += `Error for NIM ${studentId}: ${response.error}\n`;
                } else {
                    addStudentDataToTable(studentId, response);
                }

                // Memeriksa jika semua request selesai
                if (completedRequests === records.length) {
                    downloadButton.style.display = "block";
                }
            });
        });
    });
});
