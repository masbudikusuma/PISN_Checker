let csrfToken; // Variabel global untuk menyimpan csrfToken

// Fungsi untuk mengambil csrfToken dari chrome.storage.local
function getCsrfToken() {
  chrome.storage.local.get(['csrfToken'], function(result) {
    csrfToken = result.csrfToken; // Simpan csrfToken ke variabel global
  });
}

$(document).ready(function() {
  // Ambil data PISN dari chrome.storage.local
  chrome.storage.local.get(['datePddikti'], (result) => {
    // Cek apakah data PISN ada di local storage
    if (chrome.runtime.lastError || !result.datePddikti) {
      console.error("Error fetching PISN HTML atau data tidak ditemukan.");
      // Fallback: Tampilkan pesan default
      updatePisnContent("Cek Eligible PISN");
    } else {
      console.log("PISN Data:", result.datePddikti);
      // Update konten dengan data yang diambil
      updatePisnContent(result.datePddikti);
    }
  });

  // Fungsi untuk memperbarui konten di halaman
  function updatePisnContent(text) {
  const targetElement = document.querySelector(".updatepddikti");
  if (targetElement) {
    // Tambahkan teks di bawah elemen target dengan tag <strong> untuk membuatnya bold
    const newElement = document.createElement("p");
    const strongElement = document.createElement("strong");
    strongElement.textContent = text;
    newElement.appendChild(strongElement); // Menambahkan elemen strong ke dalam p
    newElement.className = "text-info mt-2"; // Tambahkan kelas styling jika diperlukan
    targetElement.appendChild(newElement);
  } else {
    console.error("Target element not found!");
  }
}

        getCsrfToken();
        $('#table_certificate_proposal_header').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                        url: "https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/list-header",
                        type: "GET",
                        dataType: "json",
                        beforeSend: function(xhr) {
                                xhr.setRequestHeader("X-Csrf-Token", csrfToken);
                                xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
                        },
                        error: function(jqXHR) {
                                // Mengecek apakah respon dari server adalah "Unauthenticated"
                                if (jqXHR.responseJSON && jqXHR.responseJSON.message === "Unauthenticated.") {
                                        Swal.fire({
                                                icon: 'warning',
                                                title: 'Session Login PISN Tidak Ditemukan',
                                                html: 'Silahkan Login terlebih dahulu di <a href="https://pisn.kemdikbud.go.id/login">pisn.kemdikbud.go.id/login</a>',
                                                confirmButtonText: 'OK'
                                        });
                                } else {
                                        Swal.fire({
                                                icon: 'error',
                                                title: 'Kesalahan',
                                                text: 'Terjadi kesalahan saat memuat data. Silakan coba lagi.',
                                                confirmButtonText: 'OK'
                                        });
                                }
                        }
                },
                columns: [{
                                data: "batch_number",
                                name: "batch_number"
                        },
                        {
                                data: "institution_name",
                                name: "i.name"
                        },
                        {
                                data: "study_level_name",
                                name: "sl.name"
                        },
                        {
                                data: "study_program_name",
                                name: "sp.name"
                        },
                        {
                                data: "created_at",
                                name: "created_at",
                                render: function(data) {
                                        return new Date(data).toLocaleDateString('id-ID', {
                                                year: 'numeric',
                                                month: 'long',
                                                day: 'numeric'
                                        });
                                }
                        },
                        {
                                data: "operator_name",
                                name: "o.name"
                        },
                        {
                                data: "action",
                                orderable: false,
                                searchable: false,
                                render: function(data, type, row) {
                                        return `<button class="btn btn-primary detail-button" 
                                    data-id="${row.id}" 
                                    data-batch-number="${row.batch_number}" 
                                    data-institution-name="${row.institution_name}" 
                                    data-study-level-name="${row.study_level_name}" 
                                    data-created_at="${row.created_at}" 
                                    data-operator_name="${row.operator_name}" 
                                    data-study-program-name="${row.study_program_name}">
                                Detail
                            </button>`;
                                }
                        }
                ],
                order: [
                        [4, "desc"]
                ]
        });
});

function showDetailModal(id, batchNumber, institutionName, studyLevelName, studyProgramName, createdat, operator_name) {
    Swal.fire({
        title: 'Detail Sertifikat',
        html: `  
        <div id="modal-content" style="font-family: Arial, sans-serif; font-size: 14px;" data-id="${id}" data-program-studi="${studyProgramName}" data-batch-number="${batchNumber}"> 
            <div class="row">
                <div class="col-lg-6">
                    <strong>Nomor Batch:</strong> ${batchNumber}<br>
                    <strong>Perguruan Tinggi:</strong>${institutionName}<br>
                    <strong>Program Pendidikan:</strong>${studyLevelName}
                </div>
                <div class="col-lg-6">
                    <strong>Program Studi:</strong> <span id="study-program-name">${studyProgramName}</span><br>
                    <strong>Tanggal:</strong> <span id="created-at">${createdat}</span><br>
                    <strong>Oleh:</strong> <span id="operator-name">${operator_name}</span>
                </div>
            </div>
            <br>
            <table class="table table-bordered" id="table_certificate_proposal_detail" width="100%" style="font-size: 13px;">
                <thead>
                    <tr>
                        <th>NIM</th>
                        <th>Nama Mahasiswa</th>
                        <th>Nomor Ijazah</th>
                        <th>Tanggal Lulus</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
            <button id="download-button" class="btn btn-success" style="margin-top: 10px;">Download Data</button>
        </div>
        `,
        width: '80%',
        showConfirmButton: true,
        confirmButtonText: 'Tutup',
        willOpen: () => {
            Swal.showLoading();
            $.ajax({
                url: `https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/list-detail/${id}`,
                type: "GET",
                dataType: "json",
                beforeSend: function(xhr) {
                    xhr.setRequestHeader("X-Csrf-Token", csrfToken);
                    xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
                },
                success: function(response) {
                    let rows = '';
                    response.data.forEach(item => {
                        rows += `<tr>
                            <td>${item.nim}</td>
                            <td>${item.student_name}</td>
                            <td>${item.certificate_number}</td>
                            <td>${item.graduation_date}</td>
                            <td>${item.inactive_text || ''}</td>
                        </tr>`;
                    });
                    $('#table_certificate_proposal_detail tbody').html(rows);
                },
                error: function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Kesalahan',
                        text: 'Tidak dapat mengambil detail sertifikat.',
                        confirmButtonText: 'OK'
                    });
                }
            });
        }
    });
}

// Event handler download untuk mengambil data program studi dan batch number dari atribut data modal
$(document).on('click', '#download-button', function() {
    const id = $('#modal-content').data('id');
    const programStudi = $('#modal-content').data('program-studi'); // Ambil program studi dari atribut data
    const batchNumber = $('#modal-content').data('batch-number');   // Ambil batch number dari atribut data

    $.ajax({
        url: 'https://pisn.kemdiktisaintek.go.id/operator/generated-certificate/export-student',
        type: 'POST',
        headers: {
            "X-Csrf-Token": csrfToken,
            "X-Requested-With": "XMLHttpRequest"
        },
        data: { certificateProposalId: id },
        xhrFields: { responseType: 'blob' },
        success: function(blob) {
            const fileName = `${programStudi}_${batchNumber}.xlsx`;
            downloadExcel(blob, fileName);
            Swal.fire({
                icon: 'success',
                title: 'Download Berhasil',
                text: 'Data telah diunduh.',
                confirmButtonText: 'OK'
            });
        },
        error: function() {
            Swal.fire({
                icon: 'error',
                title: 'Download Gagal',
                text: 'Terjadi kesalahan saat mendownload data.',
                confirmButtonText: 'OK'
            });
        }
    });
});

$(document).on('click', '.detail-button', function() {
    const id = $(this).data('id');
    const batchNumber = $(this).data('batch-number');
    const institutionName = $(this).data('institution-name');
    const studyLevelName = $(this).data('study-level-name');
    const studyProgramName = $(this).data('study-program-name');
    const createdat = $(this).data('created_at');
    const operator_name = $(this).data('operator_name');

    showDetailModal(id, batchNumber, institutionName, studyLevelName, studyProgramName, createdat, operator_name);
});

function downloadExcel(blob, fileName) {
    let link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
