// Fungsi untuk enkripsi Base64
function enkripsiBase64(teks) {
  return btoa(teks);
}

// Tampilkan progres menggunakan Swal
function showProgress(message) {
  Swal.fire({
    title: message,
    html: '<progress id="progress-bar" value="0" max="100" style="width: 100%;"></progress>',
    allowOutsideClick: false,
    didOpen: () => {
      Swal.showLoading(); // Indikator loading
    },
  });
}

function updateProgress(value) {
  const progressBar = document.getElementById("progress-bar");
  if (progressBar) {
    progressBar.value = value;
  }
}

// Sembunyikan Swal
function hideProgress() {
  Swal.close();
}

// Tampilkan pilihan role menggunakan Swal
async function selectRole(roles) {
  const roleButtons = roles.map(
    (role) =>
      `<button class="swal2-confirm role-btn" data-role-id="${role.id_peran}">
        ${role.role_name} (${role.org_name})
      </button>`
  );

  return new Promise((resolve) => {
    Swal.fire({
      title: "Pilih Role",
      html: `<div style="text-align: left;">${roleButtons.join("")}</div>`,
      showCancelButton: true,
      showConfirmButton: false, // Nonaktifkan tombol bawaan Swal
      allowOutsideClick: false,
      didOpen: () => {
        document.querySelectorAll(".role-btn").forEach((button) => {
          button.addEventListener("click", (e) => {
            const selectedRoleId = e.target.getAttribute("data-role-id");
            resolve(selectedRoleId); // Return role yang dipilih
            Swal.close(); // Tutup Swal
          });
        });
      },
    });
  });
}

// Fungsi utama untuk menjalankan proses API
document.getElementById("start-api-request").addEventListener("click", async () => {
  showProgress("Fetching username...");
  updateProgress(10);

  // Ambil username dari Chrome storage
  chrome.storage.local.get(["username", "kodept", "password"], async (result) => {
    if (!result.username || !result.kodept || !result.password) {
      Swal.fire("Error", "Username, Kode PT, atau Password tidak ditemukan di storage.", "error");
      hideProgress();
      return;
    }

    const kodept = result.kodept;
    const password = enkripsiBase64(result.password);
    const username = enkripsiBase64(result.username);

    try {
      // Langkah 1: Login
      showProgress("Logging in...");
      updateProgress(30);
      const loginResponse = await fetch("https://api-pddikti-admin.kemdikbud.go.id/login/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          Accept: "application/json",
        },
        body: new URLSearchParams({
          "data[username]": username,
          "data[password]": password,
          "data[issso]": "false",
        }),
      });

      if (!loginResponse.ok) throw new Error("Login failed");
      const loginData = await loginResponse.json();
      const i_iduser = loginData.result.session_data.i_iduser;

      // Langkah 2: Pilih Role
      showProgress("Selecting role...");
      updateProgress(60);
      const roleResponse = await fetch("https://api-pddikti-admin.kemdikbud.go.id/login/roles/1?login=adm", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          Accept: "application/json",
        },
        body: new URLSearchParams({
          "data[i_iduser]": i_iduser,
        }),
      });

      if (!roleResponse.ok) throw new Error("Role selection failed");
      const roleData = await roleResponse.json();

      let id_peran, id_organisasi, id_pengguna;

     if (roleData.result.role.length > 1) {
  console.log("Data roles:", roleData.result.role); // Debug data roles dari API

  // Pilih role jika lebih dari satu
  const selectedRoleId = await selectRole(roleData.result.role);
  console.log("Role ID yang dipilih:", selectedRoleId); // Debug ID role yang dipilih

  const selectedRole = roleData.result.role.find((role) => role.id_peran == selectedRoleId);
  console.log("Role yang dipilih:", selectedRole); // Debug detail role yang dipilih

  id_peran = selectedRole.id_peran;
  id_organisasi = selectedRole.id_organisasi;
  id_pengguna = selectedRole.id_pengguna;
} else if (roleData.result.role.length === 1) {
  // Gunakan role tunggal
  const role = roleData.result.role[0];
  console.log("Hanya satu role tersedia:", role); // Debug untuk role tunggal

  id_peran = role.id_peran;
  id_organisasi = role.id_organisasi;
  id_pengguna = role.id_pengguna;
} else {
  throw new Error("No roles available");
}


async function selectRole(roles) {
  console.log("Roles untuk dipilih:", roles); // Debug data roles

  const roleButtons = roles.map(
    (role) => {
      console.log("Membuat tombol untuk role:", role.nm_peran, "-", role.nm_lemb); // Debug teks tombol
      return `
        <button class="swal2-confirm role-btn primary" data-role-id="${role.id_peran}">
          ${role.nm_peran} - ${role.nm_lemb}
        </button>`;
    }
  );

  return new Promise((resolve) => {
    Swal.fire({
      title: "Pilih Role",
      html: `<div style="text-align: left;">${roleButtons.join("")}</div>`,
      showCancelButton: true,
      showConfirmButton: false,
      allowOutsideClick: false,
      didOpen: () => {
        document.querySelectorAll(".role-btn").forEach((button) => {
          button.addEventListener("click", (e) => {
            const selectedRoleId = e.target.getAttribute("data-role-id");
            resolve(selectedRoleId); // Kembalikan role ID yang dipilih
            Swal.close(); // Tutup SweetAlert
          });
        });
      },
    });
  });
}


      // Langkah 3: Set Login
      showProgress("Setting login...");
      updateProgress(90);
      const setLoginResponse = await fetch(
        `https://api-pddikti-admin.kemdikbud.go.id/login/setlogin/${id_peran}/${id_organisasi}?id_pengguna=${id_pengguna}&id_unit=${id_organisasi}&id_role=${id_peran}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            Accept: "application/json",
          },
          body: new URLSearchParams({
            "data[i_iduser]": i_iduser,
          }),
        }
      );

      if (!setLoginResponse.ok) throw new Error("Set login failed");
      const setLoginData = await setLoginResponse.json();

// Ambil hasil penting
const sessionData = setLoginData.result.session_data;
const { i_idunit, i_iduser: i_iduser_final, i_namarole, i_nmunit, pm } = sessionData;

// Simpan ke Chrome storage
chrome.storage.local.set({ i_idunit, i_iduser_final, i_namarole, i_nmunit, pm }, () => {
  hideProgress();
  
  // Nonaktifkan tombol setelah koneksi berhasil
  const startButton = document.getElementById("start-api-request");
  startButton.disabled = true;

  // Tampilkan pesan sukses menggunakan SweetAlert
  Swal.fire("Success", "Koneksi PDDIKTI-ADMIN berhasil terhubung.", "success");

  // Update teks respons
  document.getElementById("response-output").innerText = `Koneksi Berhasil
  `;
});

    } catch (error) {
      console.error("Error:", error.message);
      Swal.fire("Error", error.message, "error");
      hideProgress();
    }
  });
});
