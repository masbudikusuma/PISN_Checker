// Fungsi untuk mendapatkan kode PT dari chrome.localStorage dan menambah karakter tertentu
function getKodePT() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get(['kodept'], (result) => {
            if (result.kodept) {
                resolve(result.kodept); // Mengambil kodept dari chrome.storage.local
            } else {
                reject('Kode PT tidak ditemukan.');
            }
        });
    });
}

// Fungsi untuk meng-hash string menggunakan SHA1
// Fungsi untuk meng-hash string menggunakan SHA1 dan menghasilkan hasil dalam format hexadecimal
function generateSHA1(input) {
    return CryptoJS.SHA1(input).toString(CryptoJS.enc.Hex); // Menggunakan CryptoJS untuk hashing dan menghasilkan hexadecimal
}


// Event listener ketika form disubmit
document.getElementById('activationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Mencegah form untuk submit secara default

    const inputCode = document.getElementById('activationCode').value; // Mendapatkan nilai inputan

    // Mendapatkan kode PT dari chrome.storage.local dan menambah karakter tertentu
    getKodePT()
        .then(kodePT => {
            const modifiedKodePT = kodePT + '!'; // Menambahkan karakter tambahan

            // Membandingkan hash dari kode PT yang dimodifikasi dengan inputan
            const hashedKodePT = generateSHA1(modifiedKodePT);
            // Mengecek apakah hash yang dihasilkan sama dengan inputan
            if (inputCode === hashedKodePT) {
                // Jika cocok, aktivasi berhasil, simpan kode aktivasi di chrome.localStorage
                chrome.storage.local.set({ 'active': inputCode }, () => {
                    alert('Aktivasi Berhasil!');
                    window.location.href = 'tentang.html'; // Redirect ke tentang.html setelah berhasil
                });
            } else {
                // Jika tidak cocok, tampilkan pesan error
                alert('Kode Aktivasi Salah!');
            }
        })
        .catch(error => {
            alert(error); // Jika ada error saat mengambil kode PT
        });
});
