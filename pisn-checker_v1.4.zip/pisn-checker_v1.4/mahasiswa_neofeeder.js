$(document).ready(() => {
    // Variabel global untuk menyimpan URL dan token
    let globalUrl = '';
    let globalToken = '';

    // Fungsi untuk mendapatkan parameter dari URL
    function getUrlParameter(name) {
        const results = new RegExp('[?&]' + name + '=([^&#]*)').exec(window.location.href);
        if (results == null) return null;
        return decodeURIComponent(results[1]) || null;
    }

    // Fungsi untuk mendapatkan detail mahasiswa (dipindahkan ke scope global)
    function getDetailMahasiswaLulusDO(nim) {
        $.ajax({
            url: globalUrl,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                act: 'GetDetailMahasiswaLulusDO',
                token: globalToken,
                filter: `nim='${nim}'`
            }),
            success: (response) => {
                const detail = response.data[0];
                if (detail) {
                    const detailHtml = `
                        <div><strong>NIM:</strong> ${detail.nim}</div>
                        <div><strong>Nama Mahasiswa:</strong> ${detail.nama_mahasiswa}</div>
                        <div><strong>Angkatan:</strong> ${detail.angkatan}</div>
                        <div><strong>Jenis Keluar:</strong> ${detail.nama_jenis_keluar}</div>
                        <div><strong>Tanggal Keluar:</strong> ${detail.tanggal_keluar}</div>
                        <div><strong>Keterangan:</strong> ${detail.keterangan || 'Tidak ada keterangan'}</div>
                        <div><strong>Nomor SK Yudisium:</strong> ${detail.nomor_sk_yudisium || 'Tidak ada'}</div>
                        <div><strong>Tanggal SK Yudisium:</strong> ${detail.tanggal_sk_yudisium || 'Tidak ada'}</div>
                        <div><strong>IPK:</strong> ${detail.ipk}</div>
                        <div><strong>Nomor Ijazah:</strong> ${detail.nomor_ijazah || 'Tidak ada'}</div>
                        <div><strong>Judul Skripsi:</strong> ${detail.judul_skripsi || 'Tidak ada'}</div>
                        <div><strong>Asal Ijazah:</strong> ${detail.asal_ijazah || 'Tidak ada'}</div>
                        <div><strong>Periode Keluar:</strong> ${detail.id_periode_keluar}</div>
                    `;
                    $('#modalDetailBody').html(detailHtml);
                    $('#detailModal').modal('show');
                } else {
                    alert('Data detail mahasiswa tidak ditemukan.');
                }
            },
            error: (xhr, status, error) => {
                console.error('Error fetching detail mahasiswa:', error);
                alert('Terjadi kesalahan saat mengambil data detail mahasiswa.');
            }
        });
    }

    // Fungsi utama untuk memproses NIM
    function processNIM(nim) {
        chrome.storage.local.get(['url', 'username', 'password'], (result) => {
            const url = result.url;
            globalUrl = url; // Simpan URL ke variabel global
            const username = result.username;
            const password = result.password;

            function getToken(callback) {
                $.ajax({
                    url: url,
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        act: 'GetToken',
                        username: username,
                        password: password
                    }),
                    success: (response) => {
                        globalToken = response.data.token; // Simpan token ke variabel global
                        callback(response.data.token);
                    },
                    error: (xhr, status, error) => {
                        console.error('Error getting token:', error);
                        alert('Terjadi kesalahan saat mendapatkan token.');
                    }
                });
            }

            function getMahasiswa(token) {
                $.ajax({
                    url: url,
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        act: 'GetDataLengkapMahasiswaProdi',
                        token: token,
                        filter: `nim='${nim}'`
                    }),
                    success: (response) => {
                        const data = response.data[0];
                        if (data) {
                            const nikColor = data.nik && data.nik.length === 16 ? 'green' : 'red';
                            const nikLengthText = data.nik ? `Jumlah Karakter: ${data.nik.length}` : 'NIK tidak tersedia';

                            const html = `
                                <div class="col-md-16"><strong>ID Reg:</strong><br> ${data.id_registrasi_mahasiswa}</div>
                                <div class="col-md-16"><strong>ID Prodi:</strong><br> ${data.id_prodi}</div>
                                <div class="col-md-16"><strong>NIM:</strong> ${data.nim}</div>
                                <div class="col-md-16">
                                    <strong>NIK:</strong> ${data.nik}
                                    <span style="color: ${nikColor}; font-weight: bold; margin-left: 10px;">
                                        (${nikLengthText})
                                    </span>
                                </div>
                                <div class="col-md-16"><strong>Nama Mahasiswa:</strong> ${data.nama_mahasiswa}</div>
                                <div class="col-md-16"><strong>Jenis Kelamin:</strong> ${data.jenis_kelamin}</div>
                                <div class="col-md-16"><strong>Tanggal Lahir:</strong> ${data.tanggal_lahir}</div>
                                
                                <div class="col-md-16"><strong>Program Studi:</strong> ${data.nama_program_studi}</div>
                                <div class="col-md-16">
    <strong>Status Mahasiswa:</strong> ${data.nama_status_mahasiswa}
    ${['AKTIF', 'CUTI', 'NON-AKTIF'].indexOf(data.nama_status_mahasiswa.trim()) === -1
        ? `<button class="btn btn-info btn-sm detail-btn" data-nim="${nim}">Lihat Detail</button>`
        : ''
    }
</div>

                                <div class="col-md-16"><strong>Periode Masuk:</strong> ${data.id_periode_masuk}</div>
                            `;
                            $('#result').html(html);
                            $('#resultContainer').show();
                            $('#nim').val(nim);

                            getAktivitasKuliah(token, nim);
                            getRiwayatNilaiMahasiswa(token, nim);
                        } else {
                            alert('Data mahasiswa tidak ditemukan.');
                        }
                    },
                    error: (xhr, status, error) => {
                        console.error('Error fetching mahasiswa data:', error);
                        alert('Terjadi kesalahan saat mengambil data mahasiswa.');
                    }
                });
            }

            function getAktivitasKuliah(token, nim) {
                $.ajax({
                    url: url,
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        act: 'GetAktivitasKuliahMahasiswa',
                        token: token,
                        filter: `nim='${nim}'`,
                        order: 'id_semester'
                    }),
                    success: (response) => {
                        const aktivitasData = response.data;
                        if (aktivitasData && aktivitasData.length > 0) {
                            let rows = '';
                            let totalSKS = 0;

                            aktivitasData.forEach((item) => {
                                rows += `
                                    <tr>
                                        <td>${item.id_semester}</td>
                                        <td>${item.nim}</td>
                                        <td>${item.ips}</td>
                                        <td>${item.ipk}</td>
                                        <td>${item.sks_semester}</td>
                                        <td>${item.sks_total}</td>
                                        <td>${item.biaya_kuliah_smt.replace('.00', '')}</td>
                                        <td>${item.nama_status_mahasiswa}</td>
                                        <td style="color: ${item.status_sync.replace(' sync', '') === 'belum' ? 'red' : 'black'}">${item.status_sync.replace(' sync', '')}</td>

                                    </tr>
                                `;
                                totalSKS += parseInt(item.sks_semester) || 0;
                            });

                            rows += `
                                <tr>
                                    <td colspan="4" class="text-right"><b>Total SKS Semester:</b></td>
                                    <td><b>${totalSKS}</b></td>
                                    <td><-- sbg dasar PISN</td>
                                    <td colspan="3"></td>
                                </tr>
                            `;

                            $('#aktivitasTable tbody').html(rows);
                            $('#aktivitasContainer').show();
                        } else {
                            console.log('Data aktivitas kuliah tidak ditemukan.');
                            $('#aktivitasContainer').hide();
                        }
                    },
                    error: (xhr, status, error) => {
                        console.error('Error fetching aktivitas kuliah:', error);
                        alert('Terjadi kesalahan saat mengambil data aktivitas kuliah.');
                    }
                });
            }

            function getRiwayatNilaiMahasiswa(token, nim) {
                $('#loadingSpinner').show();
                $('#nilaiContainer').hide();

                $.ajax({
                    url: url,
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        act: 'GetRiwayatNilaiMahasiswa',
                        token: token,
                        filter: `nim='${nim}'`,
                        order: 'id_periode'
                    }),
                    success: (response) => {
                        const nilaiData = response.data;
                        if (nilaiData && nilaiData.length > 0) {
                            let rows = '';
                            nilaiData.forEach((item) => {
                                rows += `
                                    <tr>
                                        <td>${item.id_periode}</td>
                                        <td>${item.nama_mata_kuliah}</td>
                                        <td>${item.nama_kelas_kuliah}</td>
                                        <td>${item.sks_mata_kuliah}</td>
                                        <td>${item.nilai_angka}</td>
                                        <td>${item.nilai_huruf}</td>
                                        <td>${item.nilai_indeks}</td>
                                    </tr>
                                `;
                            });
                            $('#nilaiTable tbody').html(rows);
                            $('#nilaiContainer').show();
                        } else {
                            console.log('Data riwayat nilai tidak ditemukan.');
                            $('#nilaiContainer').hide();
                        }
                    },
                    error: (xhr, status, error) => {
                        console.error('Error fetching riwayat nilai:', error);
                        alert('Terjadi kesalahan saat mengambil data riwayat nilai.');
                    },
                    complete: () => {
                        $('#loadingSpinner').hide();
                    }
                });
            }

            getToken((newToken) => {
                getMahasiswa(newToken);
            });
        });
    }

    // Event handler untuk form submission
    $('#cekMahasiswaForm').on('submit', function (e) {
        e.preventDefault();
        const nim = $('#nim').val();
        processNIM(nim);
    });

    // Event handler untuk tombol detail (menggunakan event delegation)
    $(document).on('click', '.detail-btn', function() {
        const nim = $(this).data('nim');
        if (globalToken) {
            getDetailMahasiswaLulusDO(nim);
        } else {
            console.error('Token tidak tersedia');
            alert('Terjadi kesalahan: Token tidak tersedia');
        }
    });

    // Cek parameter NIM di URL saat halaman dimuat
    const urlNim = getUrlParameter('nim');
    if (urlNim) {
        processNIM(urlNim);
    }

// Event listener untuk tombol "Cek Data PDDIKTI"
document.getElementById('cekPddiktiButton').addEventListener('click', function () {
    const nimInput = document.getElementById('nim').value.trim();

    // Validasi apakah input NIM diisi
    if (nimInput) {
        // Buka halaman di tab baru dengan parameter NIM
        window.open(`mahasiswa_pddikti.html?nim=${encodeURIComponent(nimInput)}`, '_blank');
    } else {
        // Tampilkan alert jika NIM kosong
        alert('Harap masukkan NIM terlebih dahulu!');
    }
});


});